import trimesh
import polyscope as ps
import json
from typing import Union, Any


def polyscope_add_geometry(name: str, geometry: trimesh.Trimesh) -> ps.SurfaceMesh:
    vertices = geometry.vertices
    faces = geometry.faces
    mesh: ps.SurfaceMesh = ps.register_surface_mesh(
        name, vertices, faces
    )

    print(f'已添加网格:{name} (顶点:{len(vertices)}, 面片:{len(faces)})')
    return mesh


def load_and_show(file: str) -> None:
    mesh: Union[trimesh.Scene, Any] = trimesh.load(file)

    ps.init()
    if isinstance(mesh, trimesh.Scene):
        print(f'场景包含{len(mesh.geometry)} 个网格')
        for i, (name, geometry) in enumerate(mesh.geometry.items()):
            polyscope_add_geometry(f'mesh_{i}_{name}', geometry)
    else:
        polyscope_add_geometry('mesh', mesh)

    ps.show()


def load_and_export(file: str, json_file: str):
    mesh: Union[trimesh.Scene, Any] = trimesh.load(file)

    entities = {}
    if isinstance(mesh, trimesh.Scene):
        for i, (name, geometry) in enumerate(mesh.geometry.items()):
            component = {
                "vertices": geometry.vertices.flatten().tolist(),
                "faces": geometry.faces.flatten().tolist()
            }
            entities[name] = {
                "Mesh": component
            }
    else:
        component = {
            "vertices": mesh.vertices.flatten().tolist(),
            "faces":  mesh.faces.flatten().tolist()
        }
        entities['1'] = {
            "Mesh": component
        }

    with open(json_file, 'w') as f:
        json.dump({
            "Entities": entities
        }, f, indent=4, ensure_ascii=False)


load_and_show('simple_pole.glb')
load_and_export('simple_pole.glb', 'simple_pole.json')
