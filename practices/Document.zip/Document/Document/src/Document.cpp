﻿#include "Document.h"
#include <filesystem>
namespace fs = std::filesystem;

// Windows
#ifdef _WIN32
#include <objbase.h>
std::string generate_uuid() {
    GUID guid;
    HRESULT result = CoCreateGuid(&guid);
    char buffer[39];
    snprintf(buffer, sizeof(buffer),
        "%08lX-%04hX-%04hX-%02hhX%02hhX-%02hhX%02hhX%02hhX%02hhX%02hhX%02hhX",
        guid.Data1, guid.Data2, guid.Data3,
        guid.Data4[0], guid.Data4[1], guid.Data4[2], guid.Data4[3],
        guid.Data4[4], guid.Data4[5], guid.Data4[6], guid.Data4[7]);
    return buffer;
}
// 其他操作系统的UUID生成
#endif

class Identifier::Registry {
    std::vector<std::unique_ptr<std::string>> m_values;
    std::unordered_map<std::string_view, std::size_t> m_indexs;
public:
    Identifier CreateIdentifier(std::string value = generate_uuid())
    {
        Identifier identifier{};
        m_values.emplace_back(std::make_unique<std::string>(std::move(value)));
        std::string_view view(*m_values.back());
        std::size_t index = m_values.size();
        m_indexs[view] = index;
        identifier.m_index = index;
        identifier.m_value = view;
        return identifier;
    }

    Identifier GetIdentifier(std::string_view value) {
        Identifier identifier{};
        if (auto it = m_indexs.find(value); it != m_indexs.end()) {
            std::size_t index = it->second;
            identifier.m_index = index;
            identifier.m_value = it->first;
            return identifier;
        }
        return CreateIdentifier(std::string{ value });
    }
};

Identifier Identifier::Create(std::string_view value)
{
    static Registry registry{};
    if (value.empty()) {
        return registry.CreateIdentifier();
    }
    else {
        return registry.GetIdentifier(value);
    }
}

struct StringViewHash {
    size_t operator()(std::string_view sv) const {
        return std::hash<std::string_view>{}(sv);
    }
};

struct StringViewEqual {
    bool operator()(std::string_view lhs, std::string_view rhs) const {
        return lhs == rhs;
    }
};

class Entity::Registry {
    std::unordered_map<Identifier, Builder> m_builders;
public:
    static Registry& Get() {
        static Registry object{};
        return object;
    }

    void Add(Identifier identifier, Builder builder) {
        m_builders[identifier] = builder;
    }

    std::unique_ptr<IComponent> Create(Identifier identifier, Reader& reader) {
        if (auto it = m_builders.find(identifier); it != m_builders.end()) {
            return it->second(reader);
        }
        return nullptr;
    }
};

void Entity::Load(Reader& reader, bool complete)
{
    Registry& registry = Registry::Get();
    auto object = reader.get_object();
    for (auto field : object) {
        std::string_view key;
        field.escaped_key().get(key);
        if (key.empty()) continue;
        Identifier identifier = Identifier::Create(key);
        simdjson::ondemand::value value = field.value();
        if (auto pointer = FindComponent(identifier)) {
            if (complete) {
                pointer->Load(value);
            }
        }
        else if (auto up = registry.Create(identifier, value)) {
            if (complete) {
                up->Load(value);
            }
            m_components.emplace_back(up->GetTypeIdentifier() ,std::move(up));
        }
    }
    m_completed = complete;
    for (auto& [identifier, up] : m_components) {
        if (auto pointer = up->As<IEntityComponent>()) {
            pointer->Bind(*this);
        }
    }
}

void Entity::Save(Writer& writer, bool complete) const
{
    for (auto& [key, up] : m_components) {
        if (!up) continue;

        if (complete)
        {
            std::string_view view = key.GetValue();
            writer.Key(view.data(), view.length());
            up->Save(writer);
        }
        else if (auto pEntity = up->As<IEntityComponent>()) {
            std::string_view view = key.GetValue();
            writer.Key(view.data(), view.length());
            pEntity->SaveIndex(writer);
        }
    }
}

void Entity::Register(Identifier identifier, Builder builder)
{
    Registry::Get().Add(identifier, builder);
}

bool IEntityComponent::IsTypeImpl(TypeId id) const noexcept
{
    return GetTypeId<IEntityComponent>() == id;
}

void Document::Open(const std::string& directory)
{
    fs::path dir = directory;
    if (directory.empty()) {
        dir = fs::current_path();
    }
    if (!fs::exists(dir) || !fs::is_directory(dir)) {
        std::cerr << "invalid directory:" << dir.string() << "\n";
        return;
    }
    std::vector<fs::path> files;
    try {
        for (const auto& entry : fs::directory_iterator(dir)) {
            if (entry.is_regular_file()) {
                // 获取小写扩展名
                std::string ext = entry.path().extension().string();
                std::transform(ext.begin(), ext.end(), ext.begin(),[](unsigned char c) { return std::tolower(c); });
                if (ext == ".json") {
                    files.push_back(entry.path());
                }
            }
        }
    }
    catch (const fs::filesystem_error& e) {
        std::cerr << "filesystem error: " << e.what() << '\n';
        return;
    }

    for (auto& file : files) {
        OpenFile(file.u8string(),file.wstring());
    }
}

class DocumentFileWriter {
    fs::path m_path;
    std::string m_filename;
    fs::path m_file;
    FILE* m_pFile{};
    std::vector<char> m_buffer;
    std::unique_ptr<rapidjson::FileWriteStream> m_os;
#ifdef PRETTYWRITER
    std::unique_ptr<rapidjson::PrettyWriter<rapidjson::FileWriteStream>> m_writer;
#else
    std::unique_ptr<rapidjson::Writer<rapidjson::FileWriteStream>> m_writer;
#endif
    std::unordered_map<Identifier, Entity*> m_entities;
    int m_index{ 1 };
public:
    DocumentFileWriter() = default;
    DocumentFileWriter(fs::path path, std::string filename)
        :m_path(path), m_filename(std::move(filename)) {
    };


    void Begin(std::string filename)
    {
        m_entities.clear();
     
        m_file = m_path / (filename + ".json");
#ifdef _WIN32
        m_pFile = _wfopen(m_file.wstring().c_str(), L"wb");
#else
        m_pFile = fopen(m_file.u8string().c_str(), "wb");
#endif
        m_buffer.resize(65536);// 64KB 缓冲区
        m_os = std::make_unique<rapidjson::FileWriteStream>(m_pFile, m_buffer.data(), m_buffer.size());
#ifdef PRETTYWRITER
        m_writer = std::make_unique<rapidjson::PrettyWriter<rapidjson::FileWriteStream>>(*m_os);
#else
        m_writer = std::make_unique<rapidjson::Writer<rapidjson::FileWriteStream>>(*m_os);
#endif

        m_writer->StartObject();
        m_writer->Key("Entities");
        m_writer->StartObject();
    }

    void End()
    {
        m_writer->EndObject();
        m_writer->EndObject();
        fclose(m_pFile);

        //写入Indexes文件
#ifdef _WIN32
        fs::path index = m_file.wstring() +L".indexes";
        FILE* fp = _wfopen(index.wstring().c_str(), L"wb");
#else
        fs::path index = m_file.u8string() + ".indexes";
        FILE* fp = fopen(index.u8string().c_str(), "wb");
#endif
        std::vector<char> buffer(65536); ; // 64KB 缓冲区
        rapidjson::FileWriteStream os(fp, buffer.data(), buffer.size());
#ifdef PRETTYWRITER
        rapidjson::PrettyWriter<rapidjson::FileWriteStream> writer(os);
#else
        rapidjson::Writer<rapidjson::FileWriteStream> writer(os);
#endif
        writer.StartObject();

        writer.Key("Entities");
        writer.StartObject();

        for (auto& [identifier, pEntity] : m_entities) {
            if (!pEntity) {
                continue;
            }
            std::string_view view = identifier.GetValue();
            writer.Key(view.data(), view.length());
            writer.StartObject();
            pEntity->Save(writer, false);
            writer.EndObject();
        }
        writer.EndObject();
        writer.EndObject();
        fclose(fp);
    }

    void Write(Identifier identifier, Entity* pEntity, std::size_t limit)
    {
        if (!pEntity) return;
        std::string_view view = identifier.GetValue();
        m_writer->Key(view.data(), view.length());
        m_writer->StartObject();
        pEntity->Save(*m_writer, true);
        m_writer->EndObject();

        m_entities[identifier] = pEntity;

        // 没必要每次写入实体都检查
        constexpr auto checkFrequency = 1000;
        if (m_entities.size() < checkFrequency) return;
        auto size = ftell(m_pFile);
        if (size < limit) return;

        End();
        Begin(m_filename + std::to_string(m_index++));
    }
};


void Document::Save(const std::string& directory, std::size_t limit) const
{
    fs::path dir = directory;
    if (directory.empty()) {
        dir = fs::current_path();
    }
    if (!fs::exists(dir) || !fs::is_directory(dir)) {
        std::cerr << "invalid directory:" << dir.string() << "\n";
        return;
    }

    std::unordered_set<Identifier> identifiers;
    for (auto& [identifier, entity] : m_entities) {
        identifiers.insert(identifier);
    }

    DocumentFileWriter writer{ dir,"document"};
    writer.Begin("document");
    for (auto& [identifier, pEntity] : m_entities) {
        if (auto it = identifiers.find(identifier); it == identifiers.end()) {
            continue;
        }
        if (!pEntity) {
            continue;
        }
        writer.Write(identifier, pEntity.get(), limit);
    }
    writer.End();
}

void Document::OpenFile(const std::string& file, const std::wstring& wfile)
{
    //尝试读取索引文件,如果没有就直接读原始文件
    fs::path path = file + ".indexes";
    if (!fs::exists(path) || !fs::is_regular_file(path)) {
        path = file;
        if (!fs::exists(path) || !fs::is_regular_file(path)) {
            std::cerr << "invalid file:" << path.string() << "\n";
            return;
        }
    }

    simdjson::padded_string padded_json;
    simdjson::ondemand::document document;
    simdjson::error_code error = simdjson::padded_string::load(path.u8string()).get(padded_json);
    if (error) {
        std::cerr << error << std::endl;
        return;
    }
    
    document = m_parser.iterate(padded_json);
    auto json = document.at_pointer("/Entities");
    error = json.error();
    if (error) {
        std::cerr << error << std::endl;
        return;
    }

    auto up = std::make_unique<FileInfo>();
    up->wfile = wfile;

    std::unordered_set<Identifier> entities;
    Load(json.value(), entities, false);
    up->identifiers = entities;

    m_files[file] = std::move(up);
}

void Document::Load(Identifier identifier)
{
    std::unordered_set<Identifier> entities;
    for (auto& [file, up] : m_files) {
        if (!up) continue;
        if (up->identifiers.empty()) continue;
        if (up->identifiers.find(identifier) == up->identifiers.end())
            continue;

        fs::path path = file;
        if (!fs::exists(path) || !fs::is_regular_file(path)) {
            std::cerr << "invalid file:" << path.string() << "\n";
            continue;
        }

        simdjson::padded_string padded_json;
        simdjson::ondemand::document document;
        simdjson::error_code error = simdjson::padded_string::load(path.u8string()).get(padded_json);
        if (error) {
            std::cerr << error << std::endl;
            continue;
        }

        document = m_parser.iterate(padded_json);
        auto json = document.at_pointer("/Entities");
        error = json.error();
        if (error) {
            std::cerr << error << std::endl;
            continue;
        }
        Load(json.value(), entities, true);
    }
}

void Document::Load(Reader& reader, std::unordered_set<Identifier>& entities, bool complete)
{
    auto object = reader.get_object();
    for (auto field : object) {
        std::string_view key;
        field.escaped_key().get(key);
        if (key.empty()) continue;
        simdjson::ondemand::value value = field.value();
        Identifier identifier = Identifier::Create(key);
        if (auto it = m_entities.find(identifier); it != m_entities.end()) {
            if (it->second) {
                it->second->Load(value, complete);
                entities.insert(identifier);
            }
        }
        else if (auto up = std::make_unique<Entity>(identifier))
        {
            up->Load(value, complete);
            entities.insert(identifier);
            m_entities[identifier] = std::move(up);
        }
    }
}
