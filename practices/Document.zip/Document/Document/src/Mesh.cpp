﻿#include "Mesh.h"

Identifier Mesh::TypeIdentifier()
{
    static Identifier identifier = Identifier::Create("Mesh");
    return identifier;
}

void Mesh::Load(Reader& reader)
{
    {
        auto array = reader["vertices"];
        std::size_t size = array.count_elements();
        vertices.reserve(vertices.size() + size);
        for (auto& v : array)
        {
            vertices.push_back(v.get_double().value());
        }
    }
    {
        auto array = reader["faces"];
        std::size_t size = array.count_elements();
        faces.reserve(vertices.size() + size);
        for (auto& v : array)
        {
            faces.push_back(v.get_int64().value());
        }
    }
}

void Mesh::Save(Writer& writer) const
{
    writer.StartObject();
    writer.Key("vertices");
    writer.StartArray();
    for (auto& v : vertices) {
        writer.Double(v);
    }
    writer.EndArray();
    writer.Key("faces");
    writer.StartArray();
    for (auto& v : faces) {
        writer.Int(v);
    }
    writer.EndArray();
    writer.EndObject();
}

namespace
{
    TypeRegister<Mesh> MeshRegister{};
}
