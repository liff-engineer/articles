﻿#pragma once

#include "Document.h"

class Mesh :public Component<Mesh>
{
public:
    static Identifier TypeIdentifier();
    void Load(Reader& reader)  override;
    void Save(Writer& writer) const  override;
public:
    std::vector<float> vertices;
    std::vector<int>   faces;
};
