﻿#pragma once

#include <string>
#include <typeindex>
#include <memory>
#include <string_view>
#include <functional>
#include <unordered_map>
#include <unordered_set>
#include <cassert>

#include "simdjson.h"
#include "rapidjson/filewritestream.h"
#include "rapidjson/writer.h"
#include "rapidjson/prettywriter.h"

#define PRETTYWRITER 

using Reader = simdjson::ondemand::value;
#ifdef PRETTYWRITER
using Writer = rapidjson::PrettyWriter<rapidjson::FileWriteStream>;
#else
using Writer = rapidjson::Writer<rapidjson::FileWriteStream>;
#endif
/// @brief 类型ID
using TypeId = std::type_index;

template<typename T>
TypeId GetTypeId() {
    return typeid(T);
}

/// @brief 快速动态转换支持【采用类型ID和CRTP】
/// @tparam I 
template<typename I>
class QuickCast {
protected:
    virtual bool IsTypeImpl(TypeId id) const noexcept {
        return GetTypeId<I>() == id;
    }
public:
    template<typename T>
    bool Is() const noexcept { return IsTypeImpl(GetTypeId<T>()); }

    template<typename T>
    T* As() { return Is<T>() ? (static_cast<T*>(this)) : nullptr; }

    template<typename T>
    const T* As() const { return Is<T>() ? (static_cast<const T*>(this)) : nullptr; }
};

/// @brief 标识符
class Identifier {
public:
    /// @brief 默认构造（标识符无效）
    Identifier() = default;

    /// @brief 创建标识符
    /// @param value 字符串形式的标识符值，为空时自动分配
    /// @return 标识符
    static Identifier Create(std::string_view value={});
public:
    explicit operator bool() const noexcept { return m_index != -1; }
    inline std::string_view GetValue() const noexcept { return m_value; }
    inline long long GetIndex() const noexcept { return m_index; }
    inline bool operator<(const Identifier& other) const { return m_index < other.m_index; }
    inline bool operator==(const Identifier& other) const { return m_index == other.m_index; }
    inline bool operator!=(const Identifier& other) const { return m_index != other.m_index; }
private:
    class Registry;
    long long m_index{ -1 };
    std::string_view m_value{};
};

namespace std {
    template<>
    struct hash<Identifier> {
        size_t operator()(const Identifier& p) const {
            return static_cast<size_t>(p.GetIndex());
        }
    };
}

class IComponent:public QuickCast<IComponent> {
public:
    virtual ~IComponent() = default;
    virtual Identifier GetTypeIdentifier() const noexcept = 0;

    virtual void Load(Reader& reader) = 0;
    virtual void Save(Writer& writer) const = 0;
};

class Document;
class IEntityComponent;
class Entity final {
    // 组件添加只能通过特定入口，
    // 否则无法及时刷新关联的实体组件
    friend class Document;
    friend class IEntityComponent;
public:
    explicit Entity(Identifier identifier)
        :m_identifier(identifier) 
    {
    };
    
    inline Identifier GetIdentifier() const noexcept { return m_identifier; }
    inline bool IsCompleted() const noexcept { return m_completed; }

    void Load(Reader& reader, bool complete = true);
    void Save(Writer& writer, bool complete = true) const;
    inline bool Exist(Identifier identifer) const noexcept {
        return FindComponent(identifer) != nullptr;
    }

    template<typename T>
    T* GetComponent() const {
        static_assert(std::is_base_of_v<IComponent, T>);
        Identifier identifier = T::TypeIdentifier();
        if (auto pointer = FindComponent(identifier)) {
            return pointer->As<T>();
        }
        return nullptr;
    }
//private:
public://测试目的,暂时开放API供创建使用
    template<typename T>
    T* AddComponent() {
        static_assert(std::is_base_of_v<IComponent, T>);
        Identifier identifier = T::TypeIdentifier();
        if (auto pointer = FindComponent(identifier)) {
            return pointer->As<T>();
        }
        auto up = std::make_unique<T>();
        auto pointer = up.get();
        m_components.emplace_back(identifier,std::move(up));
        return pointer;
    }
private:
    inline IComponent* FindComponent(Identifier identifier) const {
        for (auto& [key, up] : m_components) {
            if (key == identifier) {
                return up.get();
            }
        }
        return nullptr;
    }
private:
    bool m_completed{ false };
    Identifier m_identifier;
    std::vector<std::pair<Identifier, std::unique_ptr<IComponent>>> m_components;
private:
    class Registry;
    using Builder = std::function<std::unique_ptr<IComponent>(Reader&)>;
public:
    static void Register(Identifier identifier,Builder builder);
};

template<typename T>
struct TypeRegister {
    TypeRegister() {
        static_assert(std::is_base_of_v<IComponent, T>);
        if constexpr (std::is_base_of_v<IEntityComponent, T>) {
            Entity::Register(T::TypeIdentifier(), [](Reader& reader)->std::unique_ptr<IComponent> {
                return T::Create(reader);
                });
        }
        else {
            Entity::Register(T::TypeIdentifier(), [](Reader&)->std::unique_ptr<IComponent> {
                return std::make_unique<T>();
                });
        }
    }
};

class IEntityComponent :public IComponent {
public:
    inline Identifier GetIdentifier() const noexcept { return m_entity ? m_entity->GetIdentifier() : Identifier{}; }
    inline bool IsCompleted() const noexcept { return m_entity ? m_entity->IsCompleted() : false; }
    inline Entity* GetEntity() const noexcept { return m_entity; }

    virtual void Bind(Entity& entity) { m_entity = &entity;}
    virtual void Resolve(Document& document) {};
    virtual void SaveIndex(Writer& writer) { writer.Null();}
protected:
    bool IsTypeImpl(TypeId id) const noexcept override;
protected:
    template<typename T>
    T* GetComponent() const {
        return m_entity ? m_entity->GetComponent<T>() : nullptr;
    }
    template<typename T>
    T* AddComponent() {
        return m_entity ? m_entity->AddComponent<T>() : nullptr;
    }
private:
    Entity* m_entity{};
};

template<typename T, typename I = IComponent>
class Component :public I {
public:
    Identifier GetTypeIdentifier() const noexcept override {
        return T::TypeIdentifier();
    }
protected:
    bool IsTypeImpl(TypeId id) const noexcept override {
        if (I::IsTypeImpl(id)) { return true; }
        return GetTypeId<T>() == id;
    }
};

template<typename T, typename I = IEntityComponent>
using EntityComponent = Component<T, I>;

class IRepository:public QuickCast<IRepository> {
public:
    virtual ~IRepository() = default;
    virtual Identifier GetTypeIdentifier() const noexcept = 0;
public:
    virtual void Bind(Document& document) = 0;
protected:
    Document* m_pDocument{};
};

template<typename Self, typename T>
class Repository;
class Document {
public:
    virtual ~Document() = default;

    void Open(const std::string& directory);
    void Save(const std::string& directory,std::size_t limit = 1024*1024*1024) const;

    template<typename T>
    T* GetRepository();

    template<typename T>
    const T* GetRepository() const;

    template<typename T>
    T* Get(Identifier identifier) const;

    template<typename T>
    std::unordered_map<Identifier,T*> GetAll() const {
        static_assert(std::is_base_of_v<IComponent, T>);
        std::unordered_map<Identifier,T*> results;
        for (auto& [id, up] : m_entities) {
            if (!up) continue;
            if (auto pointer = up->GetComponent<T>()) {
                results[id] = pointer;
            }
        }
        return results;
    }

    inline std::unordered_map<Identifier, Entity*> GetAllRaws() const {
        std::unordered_map<Identifier, Entity*> results;
        for (auto& [id, up] : m_entities) {
            if (!up) continue;
            results[id] = up.get();
        }
        return results;
    }

    template<typename T>
    T* TestAddEntity() {
        static_assert(std::is_base_of_v<IComponent, T>);
        auto identifier = Identifier::Create();
        auto up = std::make_unique<Entity>(identifier);
        auto pointer = up->AddComponent<T>();
        m_entities[identifier] = std::move(up);
        return pointer;
    }


    void Load(Identifier identifier);
private:
    void OpenFile(const std::string& file, const std::wstring& wfile);
    void Load(Reader& reader,std::unordered_set<Identifier>& entities,bool complete = true);
private:
    template<typename Self, typename T>
    friend class Repository;

    template<typename T>
    T* AddEntity() {
        static_assert(std::is_base_of_v<IEntityComponent, T>);
        auto identifier = Identifier::Create();
        auto up = std::make_unique<Entity>(identifier);
        auto pointer = up->AddComponent<T>();
        pointer->Bind(*up);
        m_entities[identifier] = std::move(up);
        return pointer;
    }
private:
    std::unordered_map<Identifier, std::unique_ptr<IRepository>> m_repos;
    std::unordered_map<Identifier, std::unique_ptr<Entity>> m_entities;
private:
    simdjson::ondemand::parser m_parser;
    struct FileInfo
    {
        std::wstring wfile;//没什么用,就是VS调试时中文乱码,记录这个可以对照
        std::unordered_set<Identifier> identifiers;//文件中包含的实体
    };
    std::unordered_map<std::string, std::unique_ptr<FileInfo>> m_files;
};

template<typename Self, typename T>
class Repository :public IRepository {
    static_assert(std::is_base_of_v<IEntityComponent, T>);
public:
    T* Add() {
        assert(m_pDocument);
        if (auto pointer = m_pDocument->AddEntity<T>()) {
            m_entities[pointer->GetIdentifier()] = pointer;
            return pointer;
        }
        return nullptr;
    }
    
    T* Get(Identifier identifier) {
        if (auto it = m_entities.find(identifier); it != m_entities.end()) {
            return it->second;
        }
        return nullptr;
    }

    const std::unordered_map<Identifier,T*>& GetAll(){
        return m_entities; 
    }
public:
    Identifier GetTypeIdentifier() const noexcept override { return T::TypeIdentifier(); }

    void Bind(Document& document) override {
        m_pDocument = &document;
        m_entities = document.GetAll<T>();
    }
protected:
    bool IsTypeImpl(TypeId id) const noexcept override {
        return GetTypeId<Self>() == id;
    }
protected:
    std::unordered_map<Identifier, T*> m_entities;
};

template<typename T>
inline T* Document::GetRepository()
{
    static_assert(std::is_base_of_v<IRepository, T>);
    for (auto& [identifier, pRepo] : m_repos) {
        if (!pRepo) continue;
        if (auto pResult = pRepo->As<T>()) {
            return pResult;
        }
    }
    auto up = std::make_unique<T>();
    auto pointer = up.get();
    pointer->Bind(*this);
    Identifier typeIdentifier = up->GetTypeIdentifier();
    m_repos[typeIdentifier] = std::move(up);
    return pointer;
}

template<typename T>
inline const T* Document::GetRepository() const
{
    static_assert(std::is_base_of_v<IRepository, T>);
    for (auto& [identifier, pRepo] : m_repos) {
        if (!pRepo) continue;
        if (auto pResult = pRepo->As<T>()) {
            return pResult;
        }
    }
    return nullptr;
}

template<typename T>
inline T* Document::Get(Identifier identifier) const
{
    static_assert(std::is_base_of_v<IComponent, T>);
    if (auto it = m_entities.find(identifier); it != m_entities.end()) {
        if (it->second) {
            return it->second->GetComponent<T>();
        }
    }
    return nullptr;
}
