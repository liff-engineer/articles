﻿#pragma once
#include <string>
#include <chrono>

namespace sample
{
    class TimeReporter
    {
        std::string m_name;
        std::chrono::steady_clock::time_point start;
    public:
        explicit TimeReporter(std::string name);
        ~TimeReporter();
    };

    void CreateAndSave();
    void LoadAndVisit();

    void CreateArrayedMeshDocument(
        const std::string& templateDir,
        const std::string& outputDir,
        int xCount,
        int yCount,
        double interval
    );
}
