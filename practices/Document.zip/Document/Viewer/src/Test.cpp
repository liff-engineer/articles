﻿#include "Mesh.h"
#include "Document.h"
#include "Test.h"

#include <chrono>
#include <iostream>

namespace sample
{
    TimeReporter::TimeReporter(std::string name)
        :m_name(std::move(name))
    {
        start = std::chrono::high_resolution_clock::now();
    }

    TimeReporter::~TimeReporter()
    {
        auto end = std::chrono::high_resolution_clock::now();
        auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
        std::cout<< m_name << " use: " << duration.count() << " ms" << std::endl;
    }

    class MyComponent :public Component<MyComponent>
    {
    public:
        int iV;
        double dV;
        std::string sV;
    public:
        static Identifier TypeIdentifier() {
            static Identifier identifier = Identifier::Create("MyComponent");
            return identifier;
        }

        void Load(Reader& reader)  override
        {
            iV = reader["iV"].get_int64().value();
            dV = reader["dV"].get_number().value();
            sV = reader["sV"].get_string().value();
        }

        void Save(Writer& writer) const  override
        {
            writer.StartObject();
            writer.Key("iV");
            writer.Int(iV);
            writer.Key("dV");
            writer.Double(dV);
            writer.Key("sV");
            writer.String(sV.c_str());
            writer.EndObject();
        }
    };

    class MyEntity :public EntityComponent<MyEntity>
    {
    public:
        std::string sV;
    public:
        static Identifier TypeIdentifier() {
            static Identifier identifier = Identifier::Create("MyEntity");
            return identifier;
        }

        static std::unique_ptr<MyEntity> Create(Reader& reader) {
            return std::make_unique<MyEntity>();
        }

        void Load(Reader& reader)  override
        {
            sV = reader["sV"].get_string().value();
        }

        void Save(Writer& writer) const  override
        {
            writer.StartObject();
            writer.Key("sV");
            writer.String(sV.c_str());
            writer.EndObject();
        }
    public:
        MyComponent* AddMyComponent() {
            return AddComponent<MyComponent>();
        }
        MyComponent* GetMyComponent() {
            return GetComponent<MyComponent>();
        }
    };

    class MyEntityRepository :public Repository<MyEntityRepository, MyEntity>{
    public:

    };

    namespace
    {
        TypeRegister<MyComponent> MyComponentRegister{};
        TypeRegister<MyEntity> MyEntityRegister{};
    }

    void CreateAndSave()
    {
        Document doc;
        auto pRepo = doc.GetRepository<MyEntityRepository>();
        auto pEntity = pRepo->Add();
        pEntity->sV = "liff.engineer@gmail.com";
        auto pComponent =  pEntity->AddMyComponent();
        pComponent->iV = 256;
        pComponent->dV = 3.14;
        pComponent->sV = "JSON Schema";

        doc.Save("");
    }
    void LoadAndVisit()
    {
        Document doc{};
        doc.Open("");
        auto pRepo = doc.GetRepository<MyEntityRepository>();
        auto entities = pRepo->GetAll();
        std::vector<MyComponent*> components;
        for (auto&[id,pEntity] : entities) {
            if (!pEntity) continue;
            if (!pEntity->IsCompleted()) {
                doc.Load(id);
            }
            auto pComponent = pEntity->GetMyComponent();
            if (pComponent) {
                components.push_back(pComponent);
            }
        }
    }

    void CreateArrayedMeshDocument(const std::string& templateDir, const std::string& outputDir, int xCount, int yCount, double interval)
    {
        //打开模板目录,遍历所有实体,然后确保都加载上
        Document src{};
        {
            TimeReporter openTemplate{ "【Open TemplateDir And Load All Entities】" };
            src.Open(templateDir);
            auto entities = src.GetAllRaws();
            std::cout << "Original Entities Count:" << entities.size() << "\n";
            for (auto& [id, pointer] : entities) {
                if (!pointer) continue;
                if (pointer->IsCompleted()) continue;
                src.Load(id);
            }
        }

        auto components = src.GetAll<Mesh>();
        Document doc{};
        {
            int faceCount = 0;
            TimeReporter createEntities{ "【Create Entities】" };
            for (auto& [id, pointer] : components) {
                for (int i = 0; i < xCount; i++) {
                    for (int j = 0; j < yCount; j++) {
                        std::vector<float> vertices = pointer->vertices;
                        float dx = i  * interval;
                        float dy = j  * interval;
                        for (int k = 0; k < vertices.size(); k += 3)
                        {
                            vertices[k] += dx;
                            vertices[k + 1] += dy;
                        }

                        auto pMesh = doc.TestAddEntity<Mesh>();
                        pMesh->vertices = std::move(vertices);
                        pMesh->faces = pointer->faces;

                        faceCount += pointer->faces.size() / 3;
                    }
                }
            }
            std::cout<<"New Entities Count:"<< doc.GetAllRaws().size()<<"\n";
            std::cout << "Face count:" << faceCount << "\n";
        }

        {
            TimeReporter createEntities{ "【Save New Document to Directory】" };
            doc.Save(outputDir);
        }
    }

}
