﻿#include "Document.h"
#include "Mesh.h"

#include "rapidjson/document.h"
#include "rapidjson/writer.h"
#include "rapidjson/stringbuffer.h"
#include <iostream>


void test_rapidjson()
{
    // 1. 把 JSON 解析至 DOM。
    const char* json = "{\"project\":\"rapidjson\",\"stars\":10}";
    rapidjson::Document d;
    d.Parse(json);

    // 2. 利用 DOM 作出修改。
    rapidjson::Value& s = d["stars"];
    s.SetInt(s.GetInt() + 1);

    // 3. 把 DOM 转换（stringify）成 JSON。
    rapidjson::StringBuffer buffer;
    rapidjson::Writer<rapidjson::StringBuffer> writer(buffer);
    d.Accept(writer);

    // Output {"project":"rapidjson","stars":11}
    std::cout << buffer.GetString() << std::endl;
}

#include "polyscope/polyscope.h"
#include "polyscope/surface_mesh.h"

#include "Test.h"

void LoadDocumentAndShow(const std::string& path)
{
    Document doc{};
    {
        sample::TimeReporter reporter("【LoadDocument and All Entities】");
        doc.Open(path);
        auto entities = doc.GetAllRaws();
        std::cout << "Entites Number:" << entities.size() << "\n";
        for (auto& [id, pointer] : entities) {
            if (!pointer) continue;
            if (pointer->IsCompleted()) continue;
            doc.Load(id);
        }
    }

    polyscope::init();
    
    {
        sample::TimeReporter reporter("【registerSurfaceMesh】");
        auto components = doc.GetAll<Mesh>();

        int count = 0;
        int faceCount = 0;
        constexpr auto limitCount = 1000;
        std::cout << "太多了,只显示 :" << limitCount << " 个\n";
        for (auto& [id, pointer] : components) {
            if (!pointer) continue;

            //太多了就卡死显示不出来了
            if (count++ > limitCount) {
                break;
            }

            std::vector<glm::vec3> vertices;
            vertices.reserve(pointer->vertices.size() / 3);
            for (size_t i = 0; i < pointer->vertices.size(); i += 3) {
                vertices.emplace_back(
                    pointer->vertices[i],
                    pointer->vertices[i + 1],
                    pointer->vertices[i + 2]
                );
            }
            std::vector<std::vector<std::size_t>> faces;
            faces.reserve(pointer->faces.size() / 3);
            for (size_t i = 0; i < pointer->faces.size(); i += 3) {
                std::vector<std::size_t> items;
                items.reserve(3);
                items.push_back(pointer->faces[i]);
                items.push_back(pointer->faces[i+1]);
                items.push_back(pointer->faces[i+2]);
                faces.emplace_back(
                    std::move(items)
                );
            }
            faceCount += faces.size();

            polyscope::registerSurfaceMesh(id.GetValue().data(), vertices, faces);
        }
        std::cout << "Face count:" << faceCount << "\n";
    }

    polyscope::view::resetCameraToHomeView();
    polyscope::show();
}

#include "nlohmann/json.hpp"
#include <fstream>
#include <filesystem>

int main(int argc,char** argv){
    std::string filename = "viewer.json";
    std::ifstream ifs(filename);
    if (!ifs.is_open()) {
        std::cerr << "cannot open file:" << filename << "\n";
        return -1;
    }

    nlohmann::json json = nlohmann::json::parse(ifs);
    {
        int xCount = 10;
        int yCount = 10;
        double interval = 12.0;
        try {
            if (json.contains("CreateArrayedMeshDocument")) {
                nlohmann::json j = json.at("CreateArrayedMeshDocument");
                j.at("xCount").get_to(xCount);
                j.at("yCount").get_to(yCount);
                j.at("interval").get_to(interval);
            }
        }
        catch (const nlohmann::json::exception& e) {
            std::cerr << "Jnlohmann::json error: " << e.what() << std::endl;
        }

        if (std::filesystem::exists("output")) {
            std::cout << "output directory exists; 输出目录已存在,如果内容未清除,则加载时可能加载到旧数据.\n";
        }
        sample::CreateArrayedMeshDocument("example", "output", xCount, yCount, interval);
    }
    {
#if 0
        LoadDocumentAndShow("example");
#else
        LoadDocumentAndShow("output");
#endif
        return 0;
    }


    //{
    //    sample::CreateAndSave();
    //    sample::LoadAndVisit();
    //}

    // Initialize polyscope
    polyscope::init();

    //// Register a point cloud
    //// `points` is a Nx3 array-like container of points
    //polyscope::registerPointCloud("my points", points);

    //// Register a surface mesh structure
    //// `meshVerts` is a Vx3 array-like container of vertex positions
    //// `meshFaces` is a Fx3 array-like container of face indices  
    //polyscope::registerSurfaceMesh("my mesh", meshVerts, meshFaces);

    //// Add a scalar and a vector function defined on the mesh
    //// `scalarQuantity` is a length V array-like container of values
    //// `vectorQuantity` is an Fx3 array-like container of vectors per face
    //polyscope::getSurfaceMesh("my mesh")->addVertexScalarQuantity("my_scalar", scalarQuantity);
    //polyscope::getSurfaceMesh("my mesh")->addFaceVectorQuantity("my_vector", vectorQuantity);

    // View the point cloud and mesh we just registered in the 3D UI
    polyscope::show();
    return 0;
}
