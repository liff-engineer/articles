import logging
from core import Context, Tool
from typing import Optional

class CppTypeTagger(Tool):
    tool_name = "cpp_type_tagger"
    description = "标记definition中properties的cpp语言类型"
    long_description = """
"""
    def __search_property_cpp_type(self,property:dict,identity:str)->Optional[str]:
        if 'type' not in property:
            logging.error(f"{identity}没有`type`属性,无法提供`cppType`")
        type_map = {
            "string": "std::string",
            "integer": "int",
            "number": "double",
            "boolean": "bool"
        }
        type = property['type']
        if type in type_map:
            return type_map[type]
        elif type == 'array':
            item_type = property['items']['type']
            if item_type:
                return f'std::vector<{item_type}>'
        else:
            return type
        
    def __tag_property_cpp_type(self, ctx: Context, property: dict,identity:str):
        if 'cppType' in property:
            return
        
        type = property['type']
        if type == 'array':
            self.__tag_property_cpp_type(ctx,property['items'],f'{identity}.items')
        
        cpp_type = self.__search_property_cpp_type(property,identity)
        if cpp_type:
            property["cppType"] = cpp_type
            #print(f'{identity} 的C++ 类型为 {property["cppType"]}')
        else:
            logging.error(f'无法为{identity}提供`cppType`')

    def execute(self, ctx: Context, config: dict):
        for url, definition in ctx['definition'].items():
            for member_name, member in definition['properties'].items():
                name = definition["definitionName"]
                self.__tag_property_cpp_type(ctx, member,f'{name}.{member_name}')

class CppCodeGenTest(Tool):
    tool_name = "cpp_codegen_test"
    description = "C++代码生成测试"
    long_description = """
"""

    def __generate_code(self,definition:dict):
        name = definition['definitionName']
        code = f'struct {name} {{\n'
        
        for member_name,member in definition['properties'].items():
            type = member['cppType']
            code +=f'   {type} {member_name};\n'
            
        code +=f'}};\n'
        print(code)
        pass
    
    def execute(self, ctx: Context, config: dict):
        for url,definition in ctx['definition'].items():
            self.__generate_code(definition)