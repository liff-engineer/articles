import json
import logging
from core import Context, Tool
from pathlib import Path
from typing import Optional

class FileSystemSchemaLoader(Tool):
    tool_name = "filesystem_schema_loader"
    description = "从文件系统加载JSON Schema定义"
    long_description = """
该工具将会加载shema文件，并将schema信息写入到Context['schema']，definition信息写入到Context['definition']：
- schema信息的键
    根据与`search_path`的相对路径与`url_prefix`合成`url`作为键使用
- schema信息附加内容
    - 搜索路径 `searchPath` 
    - 相对路径文件 `file`
- definition信息附加内容
    - 定义名称`definitionName`
    - 定义所属文件`definitionUrl`，即schema信息的键
"""

    def get_config_options(self) -> dict:
        return {
            "search_path": "JSON Schema搜索路径",
            "url_prefix": "路径对应的URL前缀"
        }

    def execute(self, ctx: Context, config: dict):
        search_path: str = config.get("search_path", "")
        if not search_path:
            logging.error(f"{self.tool_name}: 未指定搜索路径")

        url_prefix: str = config.get("url_prefix", "")
        if url_prefix and not url_prefix.endswith('/'):
            url_prefix += '/'

        directory = Path(search_path).resolve()

        for file_path in directory.rglob("*.json"):
            if not file_path.is_file():
                continue

            relative_path = file_path.relative_to(directory)
            url = f"{url_prefix}{relative_path.as_posix()}"

            schema = {}
            try:
                with open(file_path, 'r', encoding='utf-8') as file:
                    schema = json.load(file)
            except Exception as e:
                logging.error(f"加载JSON文件 {file_path} 失败:{str(e)}")

            if 'definitions' not in schema: 
                logging.info(
                    f'JSON 文件{file_path} 未包含"definitions",不被视作有效的JSON Schema文件')
                continue
            schema['url'] = url
            schema['searchPath'] = search_path
            schema['file'] = relative_path.as_posix()

            ctx.add_schema(url, schema)
            count = 0
            for name, definition in schema['definitions'].items():
                definition['definitionName'] = name
                definition['definitionUrl'] = url
                key = f'{url}#/definitions/{name}'
                ctx.add_definition(key, definition)
                count += 1

            logging.info(f'从JSON Schema 文件 {file_path} 加载了{count}个definition')

class PropertyTypeResolver(Tool):
    tool_name = "definition_property_type_resolver"
    description = "如果definition的property中没有定义type,而是定义了`$ref`，搜索并填充`type`"
    long_description = """
根据Context['definition']遍历所有definition,如果其property没有`type`，则根据`$ref`获取：
- 根据`$ref`搜索得到definition的`definitionName`并写入到`type`
"""

    def  __search_property_type(self,ctx:Context,ref:str,definition:dict)->Optional[str]:
        if ref == '#':
            return definition['definitionName']

        if ref.startswith("#"):
            url = definition['definitionUrl']
            ref = f'{url}{ref}'
        if ref in ctx['definition']:
            return ctx['definition'][ref]['definitionName']        
    
    def __resolve_property_type(self,ctx:Context,property:dict,definition:dict,identity:str):
        if 'type' in property:
            self.__resolve_container_property_item_type(ctx,property,definition,identity)
            return
        
        url = definition['definitionUrl']
        name = definition['definitionName']
        if '$ref' not in property:
            logging.error(f'{identity}没有`type`也没有`$ref`')        
        
        ref:str = property['$ref']
        type = self.__search_property_type(ctx,ref,definition)
        if type:
            property['type'] = type
        else:
            logging.error(f"{identity}使用的类型{ref}未找到")
        
        
    def __resolve_container_property_item_type(self,ctx:Context,property:dict,definition:dict,identity:str):
        if 'type' not in property:
            return
        type = property['type']
        if type != 'array':
            return
        if 'items' not in property:
            return
        self.__resolve_property_type(ctx,property['items'],definition,f'{identity}.items')
        
    def execute(self, ctx: Context, config: dict):
        for url,defintion in ctx['definition'].items():
            for name,property in defintion['properties'].items():
                self.__resolve_property_type(ctx,property,defintion,f'{url}的{name}')
                    