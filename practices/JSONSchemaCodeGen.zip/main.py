import argparse
import json
import logging
from core import TaskflowRunner


def main():
    parser = argparse.ArgumentParser(
        description="JSON Schema代码生成工具",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    parser.add_argument("-c", "--config", default="codegen.json",
                        help="配置文件路径")
    parser.add_argument("-v", "--verbose", action="store_true",
                        help="详细输出模式")

    parser.add_argument("--list-tools", action="store_true",
                        help="列出所有可用工具并退出")
    parser.add_argument("--tool-info", metavar="TOOL_NAME",
                        help="显示指定工具的详细信息")
    parser.add_argument("--external-tools", metavar="DIR",
                        help="加载外部工具目录")

    args = parser.parse_args()

    log_level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(level=log_level)

    runer = TaskflowRunner()

    if args.list_tools:
        print("可用工具列表:")
        for name, meta in runer.list_tools().items():
            print(f'    {name}:{meta["description"]}')
        return

    if args.tool_info:
        tools = runer.list_tools()
        if args.tool_info in tools:
            meta = tools[args.tool_info]
            print(f'工具名称:{meta["name"]}')
            print(f'描述:{meta["description"]}')
            print(f'{meta["long_description"]}')
            if meta['config_options']:
                print("配置选项:")
                for opt, desc in meta["config_options"].items():
                    print(f"    {opt}:{desc}")
        else:
            print(f"未找到工具:{args.tool_info}")
        return

    try:
        with open(args.config) as f:
            config = json.load(f)
        logging.info(f"已加载配置文件:{args.config}")
    except Exception as e:
        logging.error(f"加载配置失败: {str(e)}")
        return

    if args.external_tools:
        config["external_tools_dir"] = args.external_tools

    try:
        runer.run(config)
        logging.info("任务流执行完成")
    except Exception as e:
        logging.error("任务流执行失败:{str(e)}")


if __name__ == "__main__":
    main()
