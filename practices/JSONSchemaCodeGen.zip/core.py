import os
import logging
import sys
from typing import Dict, Any, List, Optional

TOOL = "tool"
SCHEMA = "schema"
DEFINITION = "definition"


class Context(dict):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def __missing__(self, key):
        self[key] = value = {}
        return value

    def add_tool(self, name: str, value: dict):
        self[TOOL][name] = value

    def add_schema(self, uri: str, value: dict):
        self[SCHEMA][uri] = value

    def add_definition(self, code: str, value: dict):
        self[DEFINITION][code] = value


class Tool:
    tool_name = "base_tool"
    description = ""
    long_description = ""

    def execute(self, ctx: Context, config: dict):
        raise NotImplementedError("工具必须实现execute方法")

    def get_metadata(self) -> dict:
        return {
            "name": self.tool_name,
            "description": self.description,
            "long_description": self.long_description,
            "config_options": self.get_config_options()
        }

    def get_config_options(self) -> dict:
        return {}


class TaskflowRunner:
    def __init__(self):
        self.context = Context()
        self.tools = {}
        self.__load_builtin_tools()

    def __load_builtin_tools(self):
        builtin_dir = os.path.join(os.path.dirname(__file__), "tools")
        self.load_tools_from_dir(builtin_dir)
        logging.info(f"已加载{len(self.tools)} 个内置工具")

    def load_tools_from_dir(self, directory: str):
        if not os.path.exists(directory):
            logging.warning(f"工具目录不存在:{directory}")
            return

        original_sys_path = sys.path.copy()
        sys.path.insert(0, os.path.abspath(directory))

        for filename in os.listdir(directory):
            if filename.endswith(".py") and filename != "__init__.py":
                module_name = filename[:-3]
                try:
                    module = __import__(module_name)
                    self.__register_tools_from_module(module, directory)
                except Exception as e:
                    logging.error(f"加载工具模块失败 {module_name}:{str(e)}")

        sys.path = original_sys_path

    def __register_tools_from_module(self, module, source_dir: str = ""):
        for attr_name in dir(module):
            attr = getattr(module, attr_name)
            if (isinstance(attr, type) and
                issubclass(attr, Tool) and
                    attr != Tool):
                try:
                    tool_instance = attr()
                    self.register_tool(tool_instance)

                    self.context[TOOL][tool_instance.tool_name] = tool_instance.get_metadata(
                    )

                    source = f"builtin:{os.path.basename(source_dir)}" if "builtin" in source_dir else source_dir
                    logging.debug(
                        f"注册工具 '{tool_instance.tool_name}' 从 {source}")

                except Exception as e:
                    logging.error(f"实例化工具失败 {attr_name}:{str(e)}")

    def register_tool(self, tool: Tool):
        if tool.tool_name in self.tools:
            logging.warning(f"工具已存在，将被覆盖：{tool.tool_name}")
        self.tools[tool.tool_name] = tool
        logging.info(f"已注册工具:{tool.tool_name} - {tool.description}")

    def list_tools(self) -> dict:
        return {name: tool.get_metadata() for name, tool in self.tools.items()}

    def run_task_flow(self, tool_chain: List[dict]):
        for step in tool_chain:
            tool_name = step["tool"]
            config = step.get("config", {})

            if tool_name not in self.tools:
                logging.error(f"未找到工具: {tool_name}")
                continue

            logging.info(
                f"执行工具: {tool_name} ({self.tools[tool_name].description})")
            try:
                self.tools[tool_name].execute(self.context, config)
            except Exception as e:
                logging.error(f"工具执行失败 '{tool_name}': {str(e)}")
                logging.exception(e)

            if 'children' in step:
                self.run_task_flow(step["children"])

    def run(self, config: dict):
        external_tools_dir = config.get("external_tools_dir")
        if external_tools_dir:
            logging.info(f"加载外部工具从:{ external_tools_dir}")
            self.load_tools_from_dir(external_tools_dir)

        self.run_task_flow(config.get("tasks", []))
