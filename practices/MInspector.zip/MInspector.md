[TOC]

# `MInspector`

## 方案

类实例占用的内存基本上分为两部分：

- 固定大小的内存，在栈上构造时，这部分内存会在栈上申请；
- 动态大小的内存，通常在堆上构造。

当计算一个类实例的内存占用时，可以视其为树状结构，它由其成员变量构成，而成员变量还可能包含（或`引用`）其他类实例。这里将成员变量分为以下几类：

1. 内存大小固定的基本类型，当获取类大小时会直接包含，不需要专门计算；
2. 容器类通用类型，其内存由自身大小、包含的内容项两部分构成，可提供通用实现；
3. 对象类型，由基本类型、通用类型及其他对象类型构成。

其中对象类型需要专门计算，因而可以围绕对象类型进行设计，每种类型需要提供：

- 固定占用的内存大小；
- 包含的通用类型实例，及其占用的内存大小；
- 包含的对象类型实例，其内存大小可针对其类型来获取。

这里假定每种类型可以通过类型名来区分，提供类实例来获取上述信息，可以将该操作定义为如下接口类：

```C++
//待计算的类实例
struct InspectItem {
	std::string typeName;   //类型名
    std::uintptr_t address; //
};

struct ContainerInspectItem{
	std::size_t factor;//部分容器除了其包含的类实例大小外，还有额外内存占用，与个数成比例
    std::vector<InspectItem> children; //所包含的项
};

//类实例内存占用计算结果
struct InspectPacket{
	std::size_t size;
    std::map<std::string,InspectItem> children;
    std::map<std::string,ContainerInspectItem> containerChildren;
};
```







