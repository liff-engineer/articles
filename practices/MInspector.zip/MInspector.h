#pragma once

#include <type_traits>
#include <string>
#include <vector>
#include <memory>
#include <map>
#include <unordered_map>
#include <unordered_set>

template<typename T,typename E = void>
struct IsDynamicSizeType :std::true_type {};

class MInspector;
template<typename T>
void InspectObject(MInspector& inspector, const T& v);

class MInspector
{
private:
	struct Item {
		std::string name;
		std::size_t size;
	};
	std::vector<Item> m_buffers;
public:
	template<typename T>
	void Inspect(const char* member, const T& v) {
		using U = std::decay_t<T>;
		//����T�߱���̬��Сʱ�ż�¼��ϸ��Ϣ
		if constexpr (IsDynamicSizeType<U>::value) {
			m_buffers.emplace_back(Item{ member,sizeof(v) });
			InspectObject(*this, v);
			m_buffers.pop_back();
		}
	}

	template<typename T>
	void Inspect(std::size_t index, const T& v) {
		using U = std::decay_t<T>;
		static_assert(IsDynamicSizeType<U>::value);
		m_buffers.emplace_back(Item{ std::to_string(index),sizeof(T) });
		InspectObject(*this, v);
		m_buffers.pop_back();
	}

	template<typename T>
	void DynamicInspect(const T& v) {
		using U = std::decay_t<T>;
		static_assert(std::is_same_v<T, U>);
		auto& typeInfo = typeid(U);
		std::size_t typeId = typeInfo.hash_code();
		std::string typeName = typeInfo.name();
		std::uintptr_t address = (std::uintptr_t)(void*)(&v);
	}

	void UpdateSize(std::size_t size)
	{
		if (m_buffers.empty()) return;
		m_buffers.back().size = size;
	}
};

template<>
struct IsDynamicSizeType<bool> : std::false_type {};

template<typename T>
struct IsDynamicSizeType<T, std::enable_if_t<std::is_integral_v<T>>> :std::false_type {};

template<typename T>
struct IsDynamicSizeType<T, std::enable_if_t<std::is_floating_point_v<T>>> :std::false_type {};

template<typename T>
struct IsDynamicSizeType<T, std::enable_if_t<std::is_enum_v<T>>> :std::false_type {};

template<typename T,typename E = void>
struct InspectHelper :std::false_type {
	static void Inspect(MInspector& inspector, const T& v) {
		inspector.DynamicInspect(v);
	}
};

template<typename T>
inline void InspectObject(MInspector& inspector, const T& v)
{
	InspectHelper<T>::Inspect(inspector, v);
}

template<>
struct InspectHelper<std::string>
{
	static void Inspect(MInspector& inspector, const std::string& v) {
		inspector.UpdateSize(v.capacity() * sizeof(char));
	}
};

template<typename T>
struct InspectHelper<std::vector<T>>
{
	static void Inspect(MInspector& inspector, const std::vector<T>& v) {
		if constexpr (IsDynamicSizeType<T>::value) {
			for (std::size_t i = 0; i < v.size(); i++)
			{
				inspector.Inspect(i, v.at(i));
			}
		}
		else
		{
			inspector.UpdateSize(v.capacity() * sizeof(T));
		}
	}
};