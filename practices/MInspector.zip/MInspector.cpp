#include <iostream>
#include <string>
#include <vector>
#include <memory>
#include <set>
#include <unordered_set>

#include <malloc.h>
#include "MInspector.h"

class Object {
	bool bV;
	int iV;
	double dV;
	std::string sV;
	std::vector<std::unique_ptr<Object>> oVs;
};

void Inspect(const std::string& obj) {
	auto& typeId = typeid(obj);
	std::cout << "type:" << typeId.name() << "\n";
	std::cout << "typeId: " << typeId.hash_code() << "\n";
	std::cout << "stack size:" << sizeof(obj) << "\n";
	std::cout << "heap size:" << ::_msize(reinterpret_cast<void*>(const_cast<char*>(obj.data()))) << "\n";
	std::cout << "heap used size:" << obj.length() * sizeof(char) << "\n";
	std::cout << "capacity:" << obj.capacity()*sizeof(char) << "\n";
}

void Inspect(const Object* obj) {
	auto& typeId = typeid(obj);
	std::cout << "type:" << typeId.name() << "\n";
	std::cout << "typeId: " << typeId.hash_code() << "\n";
	std::cout << "size:" << sizeof(obj) << "\n";
}

class MyObject {
	int iV{};
	double dV{};
	std::string sV{"liff.engineer@gmail.com"};
	std::vector<std::string> sVs{ "liff.engineer@gmail.com" ,"liff.engineer@gmail.com" };
public:
	MyObject() = default;
private:
	//friend void InspectObject(MInspector&, const MyObject&);
};

//void InspectObject(MInspector& inspector, const MyObject& v)
//{
//	inspector.Inspect("iV", v.iV);
//	inspector.Inspect("dV", v.dV);
//	inspector.Inspect("sV", v.sV);
//	inspector.Inspect("sVs", v.sVs);
//}

int main()
{
	MInspector inspector;
	MyObject obj{};
	inspector.Inspect("GlobalInstance", obj);
	return 0;
}
