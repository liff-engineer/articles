#define SOL_ALL_SAFETIES_ON 1
#include <sol/sol.hpp>
#include <cassert>
#include <iostream>


int main() {
    std::cout << "=== opening a state ===\n";
    sol::state lua;
    lua.open_libraries(sol::lib::base, sol::lib::package);
    lua.script("print('bark bark bark!')");

    std::cout << "\n";
    return 0;
}