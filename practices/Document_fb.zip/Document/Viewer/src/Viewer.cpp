﻿#include "Document.h"
#include "Mesh.h"
#include "JsonSerializer.h"
#include "IFlatBuffersSerializer.h"

#include <iostream>

#include "polyscope/polyscope.h"
#include "polyscope/surface_mesh.h"

#include "Test.h"

void LoadDocumentAndShow(const std::string& path,bool existJsonFormat,bool existFlatBuffersFormat)
{
    Document doc{};

    if(existJsonFormat)
    {
        doc.SetSerializers({"Json"});
        sample::TimeReporter reporter("【LoadDocument and All Entities】");
        doc.Open(path);
        auto entities = doc.GetAll();
        std::cout << "Entites Number:" << entities.size() << "\n";
        for (auto& [id, pointer] : entities) {
            if (!pointer) continue;
            if (pointer->IsCompleted()) continue;
            doc.Load(id);
        }
    }

    Document other{};
    if(existFlatBuffersFormat)
    {
        other.SetSerializers({ "FlatBuffers" });
        sample::TimeReporter reporter("【FlatBuffers】【LoadDocument and All Entities】");
        other.Open(path+"_fb");
        auto entities = other.GetAll();
        std::cout << "Entites Number:" << entities.size() << "\n";
        for (auto& [id, pointer] : entities) {
            if (!pointer) continue;
            if (pointer->IsCompleted()) continue;
            other.Load(id);
        }
    }

    polyscope::init();
    
    {
        sample::TimeReporter reporter("【registerSurfaceMesh】");
        auto components = other.GetAll<Mesh>();
        if (!existFlatBuffersFormat) {
            components = doc.GetAll<Mesh>();
        }

        int count = 0;
        int faceCount = 0;
        constexpr auto limitCount = 1000;
        std::cout << "太多了,只显示 :" << limitCount << " 个\n";
        for (auto& [id, pointer] : components) {
            if (!pointer) continue;

            //太多了就卡死显示不出来了
            if (count++ > limitCount) {
                break;
            }

            std::vector<glm::vec3> vertices;
            vertices.reserve(pointer->vertices.size() / 3);
            for (size_t i = 0; i < pointer->vertices.size(); i += 3) {
                vertices.emplace_back(
                    pointer->vertices[i],
                    pointer->vertices[i + 1],
                    pointer->vertices[i + 2]
                );
            }
            std::vector<std::vector<std::size_t>> faces;
            faces.reserve(pointer->faces.size() / 3);
            for (size_t i = 0; i < pointer->faces.size(); i += 3) {
                std::vector<std::size_t> items;
                items.reserve(3);
                items.push_back(pointer->faces[i]);
                items.push_back(pointer->faces[i+1]);
                items.push_back(pointer->faces[i+2]);
                faces.emplace_back(
                    std::move(items)
                );
            }
            faceCount += faces.size();

            polyscope::registerSurfaceMesh(id.GetValue().data(), vertices, faces);
        }
        std::cout << "Face count:" << faceCount << "\n";
    }

    polyscope::view::resetCameraToHomeView();
    polyscope::show();
}

#include "nlohmann/json.hpp"
#include <fstream>
#include <filesystem>

int main(int argc,char** argv){
    std::string filename = "viewer.json";
    std::ifstream ifs(filename);
    if (!ifs.is_open()) {
        std::cerr << "cannot open file:" << filename << "\n";
        return -1;
    }
    bool create_json_format = true;
    bool create_flatbuffers_format = true;

    nlohmann::json json = nlohmann::json::parse(ifs);
    {
        int xCount = 10;
        int yCount = 10;
        double interval = 12.0;
        try {
            if (json.contains("CreateArrayedMeshDocument")) {
                nlohmann::json j = json.at("CreateArrayedMeshDocument");
                j.at("xCount").get_to(xCount);
                j.at("yCount").get_to(yCount);
                j.at("interval").get_to(interval);
                j.at("createJson").get_to(create_json_format);
                j.at("createFlatBuffers").get_to(create_flatbuffers_format);
            }
        }
        catch (const nlohmann::json::exception& e) {
            std::cerr << "Jnlohmann::json error: " << e.what() << std::endl;
        }

        if (std::filesystem::exists("output")) {
            std::cout << "output directory exists; 输出目录已存在,如果内容未清除,则加载时可能加载到旧数据.\n";
        }
        sample::CreateArrayedMeshDocument("example", "output", xCount, yCount, interval,create_json_format,create_flatbuffers_format);
    }
    {
#if 0
        LoadDocumentAndShow("example");
#else
        LoadDocumentAndShow("output",create_json_format,create_flatbuffers_format);
#endif
        return 0;
    }


    //{
    //    sample::CreateAndSave();
    //    sample::LoadAndVisit();
    //}

    // Initialize polyscope
    polyscope::init();

    //// Register a point cloud
    //// `points` is a Nx3 array-like container of points
    //polyscope::registerPointCloud("my points", points);

    //// Register a surface mesh structure
    //// `meshVerts` is a Vx3 array-like container of vertex positions
    //// `meshFaces` is a Fx3 array-like container of face indices  
    //polyscope::registerSurfaceMesh("my mesh", meshVerts, meshFaces);

    //// Add a scalar and a vector function defined on the mesh
    //// `scalarQuantity` is a length V array-like container of values
    //// `vectorQuantity` is an Fx3 array-like container of vectors per face
    //polyscope::getSurfaceMesh("my mesh")->addVertexScalarQuantity("my_scalar", scalarQuantity);
    //polyscope::getSurfaceMesh("my mesh")->addFaceVectorQuantity("my_vector", vectorQuantity);

    // View the point cloud and mesh we just registered in the 3D UI
    polyscope::show();
    return 0;
}
