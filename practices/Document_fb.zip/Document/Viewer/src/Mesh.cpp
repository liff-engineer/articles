﻿#include "Mesh.h"

TypeIndex Mesh::TypeIdentifier()
{
    static TypeIndex identifier = TypeIndex::Create("Mesh");
    return identifier;
}


//namespace
//{
//    TypeRegister<Mesh> MeshRegister{};
//}
