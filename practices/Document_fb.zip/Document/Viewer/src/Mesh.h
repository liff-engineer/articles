﻿#pragma once

#include "Document.h"

class Mesh :public Component<Mesh>
{
public:
    static TypeIndex TypeIdentifier();
public:
    std::vector<float> vertices;
    std::vector<int>   faces;
};
