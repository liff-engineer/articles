﻿#include "IFlatBuffersSerializer.h"
#include "Mesh.h"
#include "generated/Document_generated.h"

void from_flatbuffers(const AccessToken& token, const void* buffer, std::size_t type, Mesh& object)
{
    if (type != fb::ComponentData_Mesh) return;
    auto pMesh = static_cast<const fb::Mesh*>(buffer);
    if (!pMesh) return;
    object.vertices.insert(object.vertices.end(),pMesh->vertices()->begin(),pMesh->vertices()->end());
    object.faces.insert(object.faces.end(), pMesh->faces()->begin(), pMesh->faces()->end());
}

void to_flatbuffers(const AccessToken& token, flatbuffers::FlatBufferBuilder& builder, flatbuffers::Offset<void>& offset, std::size_t& type, const Mesh& object)
{
    offset = fb::CreateMesh(builder,
        builder.CreateVector(object.vertices),
        builder.CreateVector(object.faces)
        ).Union();
    type = fb::ComponentData_Mesh;
}

namespace
{
    FlatBuffersSerializerRegister<Mesh> MeshFlatBuffersSerializerRegister{};
}
