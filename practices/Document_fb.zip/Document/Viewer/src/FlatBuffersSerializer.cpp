﻿#include "IFlatBuffersSerializer.h"

#include "generated/Document_generated.h"
#include <iostream>

class FlatBuffersSerializer :public IFlatBuffersSerializer {
public:

protected:
    bool IsAcceptedFile(const std::string& file, const std::string& ext) const override;
    void VisitFile(Document& document, const AccessToken& token, const std::vector<char>& buffer, std::unordered_set<Identifier>& entities, bool complete);
    void WriteFileBegin(std::string& filename);
    void WriteComponent(flatbuffers::FlatBufferBuilder& builder, TypeIndex identifier, flatbuffers::Offset<void> offset, std::size_t type);
    void WriteEntity(flatbuffers::FlatBufferBuilder& builder, Identifier identifier);
    void WriteFileEnd(flatbuffers::FlatBufferBuilder& builder, const std::unordered_set<TypeIndex>& typeIndexes);
private:
    std::vector<flatbuffers::Offset<fb::Entity>>    m_entities;
    std::vector<flatbuffers::Offset<fb::Component>> m_components;
};

bool FlatBuffersSerializer::IsAcceptedFile(const std::string& file, const std::string& ext) const
{
    return ext == fb::FileExtension();
}

void FlatBuffersSerializer::VisitFile(Document& document, const AccessToken& token, const std::vector<char>& buffer, std::unordered_set<Identifier>& entities, bool complete)
{
    // 验证文件标识符
    if (!flatbuffers::BufferHasIdentifier(
        reinterpret_cast<const uint8_t*>(buffer.data()), fb::FileIdentifier())) {
        std::cerr << "Invalid file identifier" << std::endl;
        return;
    }

    if (auto pFile = fb::GetFile(buffer.data())) {
        for (const auto& pTypeIndex : *(pFile->component_type_indexes())) {
            VisitTypeIndex(pTypeIndex->identifier()->c_str(), pTypeIndex->index());
        }
        for (const auto& pRawEntity : *(pFile->entities())) {
            if (Entity* pEntity = VisitEntityBegin(document, token, pRawEntity->identifier()->c_str())) {
                for (const auto& pComponent : *(pRawEntity->components())) {
                    VisitComponent(token, *pEntity, pComponent->index(), pComponent->data(), pComponent->data_type(), complete);
                }
                VisitEntityEnd(document ,*pEntity, entities, complete);
            }
        }
    }
}

void FlatBuffersSerializer::WriteFileBegin(std::string& filename)
{
    m_components.clear();
    m_entities.clear();
    filename += fb::FileExtension();
}

void FlatBuffersSerializer::WriteComponent(flatbuffers::FlatBufferBuilder& builder, TypeIndex identifier, flatbuffers::Offset<void> offset, std::size_t type)
{
    m_components.emplace_back(
        fb::CreateComponent(
            builder,
            identifier.GetIndex(),
            static_cast<fb::ComponentData>(type),
            offset
        )
    );
}

void FlatBuffersSerializer::WriteEntity(flatbuffers::FlatBufferBuilder& builder, Identifier identifier)
{
    m_entities.emplace_back(fb::CreateEntity(builder,
        builder.CreateString(identifier.GetValue()),
        builder.CreateVector(m_components))
    );
    m_components.clear();
}

void FlatBuffersSerializer::WriteFileEnd(flatbuffers::FlatBufferBuilder& m_builder, const std::unordered_set<TypeIndex>& m_types)
{
    std::vector<flatbuffers::Offset<fb::ComponentTypeIndex>> typeIndexes;
    for (auto& index : m_types) {
        typeIndexes.emplace_back(fb::CreateComponentTypeIndex(m_builder,
            m_builder.CreateString(index.GetValue()),
            index.GetIndex()));
    }

    auto file = fb::CreateFile(m_builder,
        m_builder.CreateVector(typeIndexes),
        m_builder.CreateVector(m_entities));

    m_builder.Finish(file, fb::FileIdentifier());
}

namespace
{
    SerializerRegister<FlatBuffersSerializer> FlatBuffersSerializerRegister{"FlatBuffers"};
}
