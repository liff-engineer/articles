﻿#include "Mesh.h"
#include "JsonSerializer.h"

void from_json(const AccessToken& token, JsonSerializer::Reader& reader, Mesh& object)
{
    {
        auto array = reader["vertices"];
        std::size_t size = array.count_elements();
        object.vertices.reserve(object.vertices.size() + size);
        for (auto& v : array)
        {
            object.vertices.push_back(v.get_double().value());
        }
    }
    {
        auto array = reader["faces"];
        std::size_t size = array.count_elements();
        object.faces.reserve(object.vertices.size() + size);
        for (auto& v : array)
        {
            object.faces.push_back(v.get_int64().value());
        }
    }
}

void to_json(const AccessToken& token, JsonSerializer::Writer& writer, const Mesh& object)
{
    writer.StartObject();
    writer.Key("vertices");
    writer.StartArray();
    for (auto& v : object.vertices) {
        writer.Double(v);
    }
    writer.EndArray();
    writer.Key("faces");
    writer.StartArray();
    for (auto& v : object.faces) {
        writer.Int(v);
    }
    writer.EndArray();
    writer.EndObject();
}

namespace
{
    static JsonSerializerRegister<Mesh> meshRegister{};
}
