﻿#pragma once

#include "Document.h"

#include "simdjson.h"
#include "rapidjson/filewritestream.h"
#include "rapidjson/writer.h"
#include "rapidjson/prettywriter.h"

#define PRETTYWRITER 


using JsonReader = simdjson::ondemand::value;
#ifdef PRETTYWRITER
using JsonWriter = rapidjson::PrettyWriter<rapidjson::FileWriteStream>;
#else
using JsonWriter = rapidjson::Writer<rapidjson::FileWriteStream>;
#endif
class DocumentJsonFileWriter;

/// @brief JSON序列化/反序列化实现
/// 
/// 组件支持方式如下：
/// 1. 提供from_json/to_json实现
/// 2. 通过JsonSerializerRegister注册
/// 注意业务组件的实现：
/// 1. from_json需要两个来分别支持创建与加载
/// 2. to_json多一个complete参数来支持保存所有和全量保存
class JsonSerializer :public ISerializer {
    friend class DocumentJsonFileWriter;
public:
    using Reader = JsonReader;
    using Writer = JsonWriter;
public:
    JsonSerializer() = default;
private:
    bool IsAcceptedFile(const std::string& file, const std::string& ext) const override;
    void Open(Document& document, const AccessToken& token, const std::string& file, std::unordered_set<Identifier>& entities, bool complete = true) override;
    void Save(const Document& document, const AccessToken& token, const std::string& directory, const std::string& filename, const std::unordered_set<Identifier>& entities, std::size_t limit) override;

    void Load(Document& document, const AccessToken& token, Reader& reader, std::unordered_set<Identifier>& entities, bool complete = true);
    void Load(Document& document, const AccessToken& token, Entity& entity, Reader& reader, bool complete = true);
private:
    simdjson::ondemand::parser m_parser;
protected:
    bool IsTypeImpl(TypeId id) const noexcept override {
        return GetTypeId<JsonSerializer>() == id;
    }
#pragma region Adapter
private:
    class IAdapter {
    public:
        virtual ~IAdapter() = default;
        virtual std::unique_ptr<IComponent> Create(const AccessToken& token, Reader& reader) = 0;
        virtual void Load(const AccessToken& token, Reader& reader, IComponent& object) = 0;
        virtual void Save(const AccessToken& token, Writer& writer, const IComponent& object, bool complete) = 0;
    };

    template<typename T>
    class Adapter final :public IAdapter {
        static_assert(std::is_base_of_v<IComponent, T>);
    public:
        std::unique_ptr<IComponent> Create(const AccessToken& token, Reader& reader) override {
            if constexpr (std::is_base_of_v<IEntityComponent, T>) {
                std::unique_ptr<T> up;
                from_json(token, reader, up);
                return up;
            }
            else {
                return std::make_unique<T>();
            }
        }
        void Load(const AccessToken& token, Reader& reader, IComponent& object) override {
            if (T* pointer = object.As<T>()) {
                from_json(token, reader, *pointer);
            }
        }
        void Save(const AccessToken& token, Writer& writer, const IComponent& object, bool complete) override {
            if (const T* pointer = object.As<T>()) {
                if constexpr (std::is_base_of_v<IEntityComponent, T>) {
                    to_json(token, writer, *pointer, complete);
                }
                else {
                    to_json(token, writer, *pointer);
                }
            }
        }
    };
    static inline IAdapter* GetAdapter(TypeIndex identifier) {
        if (GetAdapters().size() > identifier.GetIndex()) {
            return GetAdapters()[identifier.GetIndex()].get();
        }
        return nullptr;
    }
#pragma endregion

public:
    static std::vector<std::unique_ptr<IAdapter>>& GetAdapters();

    template<typename T>
    class Register {
        static_assert(std::is_base_of_v<IComponent, T>);
    public:
        Register() {
            TypeIndex index = T::TypeIdentifier();
            auto& adapters = GetAdapters();
            if (adapters.size() <= index.GetIndex()) {
                adapters.resize(index.GetIndex() + 1);
            }
            adapters[index.GetIndex()] = std::make_unique<Adapter<T>>();
        }
    };
};

template<typename T>
using JsonSerializerRegister = JsonSerializer::Register<T>;
