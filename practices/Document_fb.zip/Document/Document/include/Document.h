﻿#pragma once

#include <string>
#include <typeindex>
#include <memory>
#include <vector>
#include <string_view>
#include <functional>
#include <unordered_map>
#include <unordered_set>
#include <cassert>

/// @brief 类型ID
using TypeId = std::type_index;

template<typename T>
TypeId GetTypeId() {
    return typeid(T);
}

/// @brief 快速动态转换支持【采用类型ID和CRTP】
/// @tparam I 
template<typename I>
class QuickCast {
protected:
    virtual bool IsTypeImpl(TypeId id) const noexcept {
        return GetTypeId<I>() == id;
    }
public:
    template<typename T>
    bool Is() const noexcept { return IsTypeImpl(GetTypeId<T>()); }

    template<typename T>
    T* As() { return Is<T>() ? (static_cast<T*>(this)) : nullptr; }

    template<typename T>
    const T* As() const { return Is<T>() ? (static_cast<const T*>(this)) : nullptr; }
};

template<typename T>
class IndexedIdentifier {
public:
    IndexedIdentifier() = default;
    static T Create(std::string_view value = {}) {
        return T::CreateImpl(value);
    }
public:
    explicit operator bool() const noexcept { return !m_value.empty(); }
    inline std::string_view GetValue() const noexcept { return m_value; }
    inline long long GetIndex() const noexcept { return m_index; }
    inline bool operator<(const T& other) const { return m_index < other.m_index; }
    inline bool operator==(const T& other) const { return m_index == other.m_index; }
    inline bool operator!=(const T& other) const { return m_index != other.m_index; }
protected:
    class Registry {
        std::vector<std::unique_ptr<std::string>> m_values;
        std::unordered_map<std::string_view, std::size_t> m_indexs;
    public:
        T CreateIdentifier(std::string value)
        {
            T identifier{};
            m_values.emplace_back(std::make_unique<std::string>(std::move(value)));
            std::string_view view(*m_values.back());
            std::size_t index = m_values.size();
            m_indexs[view] = index;
            identifier.m_index = index;
            identifier.m_value = view;
            return identifier;
        }

        T GetIdentifier(std::string_view value) {
            T identifier{};
            if (auto it = m_indexs.find(value); it != m_indexs.end()) {
                std::size_t index = it->second;
                identifier.m_index = index;
                identifier.m_value = it->first;
                return identifier;
            }
            return CreateIdentifier(std::string{ value });
        }
    };
    long long m_index{};
    std::string_view m_value{};
};

/// @brief 实体标识符
class Identifier :public IndexedIdentifier<Identifier>{
public:
    static Identifier CreateImpl(std::string_view value = {});
};

/// @brief 类型索引
class TypeIndex :public IndexedIdentifier<TypeIndex> {
public:
    static TypeIndex CreateImpl(std::string_view value={});
};

namespace std {
    template<>
    struct hash<Identifier> {
        size_t operator()(const Identifier& p) const {
            return static_cast<size_t>(p.GetIndex());
        }
    };

    template<>
    struct hash<TypeIndex> {
        size_t operator()(const TypeIndex& p) const {
            return static_cast<size_t>(p.GetIndex());
        }
    };
}

class Document;
/// @brief 访问用令牌
class AccessToken final {
    friend class Document;
    AccessToken() = default;
public:
    AccessToken(const AccessToken&) = delete;
    AccessToken& operator=(const AccessToken&) = delete;
};

/// @brief 业务组件
class IComponent:public QuickCast<IComponent> {
public:
    virtual ~IComponent() = default;
    virtual TypeIndex GetTypeIdentifier() const noexcept = 0;
};

class IEntityComponent;

/// @brief 实体
/// 提供两种状态：
/// 1. 未完成：实体及业务实体类型信息可用，支持实体引用的访问
/// 2. 完成：组件信息可用，支持业务实体信息访问
class Entity final {
    friend class IEntityComponent;
public:
    explicit Entity(Identifier identifier)
        :m_identifier(identifier)
    {
    };

    inline Identifier GetIdentifier() const noexcept { return m_identifier; }
    inline bool IsCompleted() const noexcept { return m_completed; }

    inline bool Exist(TypeIndex identifer) const noexcept {
        return FindComponent(identifer) != nullptr;
    }

    template<typename T>
    T* GetComponent() const {
        static_assert(std::is_base_of_v<IComponent, T>);
        TypeIndex identifier = T::TypeIdentifier();
        if (auto pointer = FindComponent(identifier)) {
            return pointer->As<T>();
        }
        return nullptr;
    }

    inline IComponent* GetComponent(const AccessToken& token, TypeIndex identifier) const {
        for (auto& [key, up] : m_components) {
            if (key == identifier) { return up.get(); }
        }
        return nullptr;
    }

    template<typename Fn>
    void Visit(const AccessToken& token, Fn fn) const {
        for (auto& [id, up] : m_components) {
            if (up) { fn(id,*up); }
        }
    }

    template<typename T>
    T* AddComponent(const AccessToken& token, std::unique_ptr<T> up)
    {
        static_assert(std::is_base_of_v<IComponent, T>);
        auto pointer = up.get();
        m_components.emplace_back(up->GetTypeIdentifier(), std::move(up));
        return pointer;
    }

    void MarkCompleted(Document& document,const AccessToken& token);
private:
    template<typename T>
    T* AddComponent() {
        static_assert(std::is_base_of_v<IComponent, T>);
        TypeIndex identifier = T::TypeIdentifier();
        if (auto pointer = FindComponent(identifier)) {
            return pointer->As<T>();
        }
        auto up = std::make_unique<T>();
        auto pointer = up.get();
        m_components.emplace_back(identifier,std::move(up));
        return pointer;
    }
private:
    inline IComponent* FindComponent(TypeIndex identifier) const {
        for (auto& [key, up] : m_components) {
            if (key == identifier) {
                return up.get();
            }
        }
        return nullptr;
    }
private:
    bool m_completed{ false };
    Identifier m_identifier;
    std::vector<std::pair<TypeIndex, std::unique_ptr<IComponent>>> m_components;
};

/// @brief 实体组件（对应业务实体）
class IEntityComponent :public IComponent {
public:
    inline Identifier GetIdentifier() const noexcept { return m_entity ? m_entity->GetIdentifier() : Identifier{}; }
    inline bool IsCompleted() const noexcept { return m_entity ? m_entity->IsCompleted() : false; }
    inline Entity* GetEntity() const noexcept { return m_entity; }

    /// @brief 绑定实体（自身信息可用）
    /// 调用时机：
    /// 1. 实体组件加载完成时
    /// 2. 新建实体组件后
    /// @param entity 
    virtual void Bind(Entity& entity) { m_entity = &entity;}

    /// @brief 处理实体引用信息
    /// 调用时机：实体组件加载完成时，实体已处于完成状态
    /// @param document 
    virtual void Resolve(Document& document) {};
protected:
    bool IsTypeImpl(TypeId id) const noexcept override;
protected:
    template<typename T>
    T* GetComponent() const {
        return m_entity ? m_entity->GetComponent<T>() : nullptr;
    }
    template<typename T>
    T* AddComponent() {
        return m_entity ? m_entity->AddComponent<T>() : nullptr;
    }
private:
    Entity* m_entity{};
};

template<typename T, typename I = IComponent>
class Component :public I {
public:
    TypeIndex GetTypeIdentifier() const noexcept override {
        return T::TypeIdentifier();
    }
protected:
    bool IsTypeImpl(TypeId id) const noexcept override {
        if (I::IsTypeImpl(id)) { return true; }
        return GetTypeId<T>() == id;
    }
};

template<typename T, typename I = IEntityComponent>
using EntityComponent = Component<T, I>;

/// @brief 特定业务实体存储库
class IRepository:public QuickCast<IRepository> {
public:
    virtual ~IRepository() = default;

    /// @brief 获取分类信息
    /// 该信息用来保存时作为文件名，相同分类会存储到相同文件
    /// @return 
    virtual const std::string& GetClassifier() const noexcept = 0;

    /// @brief 获取对应的实体组件类型标识符
    /// @return 
    virtual TypeIndex GetTypeIdentifier() const noexcept = 0;
public:
    /// @brief 绑定文档来初始化存储状态
    /// @param document 
    virtual void Bind(Document& document) = 0;

    /// @brief 新建业务组件时通知更新存储状态
    /// @param entity 
    virtual void Notify(IEntityComponent& entity) = 0;
protected:
    Document* m_pDocument{};
};

/// @brief 序列化与反序列化接口
class ISerializer :public QuickCast<ISerializer> {
public:
    virtual ~ISerializer() = default;

    virtual bool IsAcceptedFile(const std::string& file, const std::string& ext) const = 0;
    virtual void Open(Document& document, const AccessToken& token, const std::string& file, std::unordered_set<Identifier>& entities, bool complete) = 0;
    virtual void Save(const Document& document, const AccessToken& token, const std::string& directory, const std::string& filename, const std::unordered_set<Identifier>& entities, std::size_t limit) = 0;
#pragma region Registry
private:
    using Builder = std::function<std::unique_ptr<ISerializer>()>;
    static std::unordered_map<std::string, Builder>& GetBuilders();
public:
    template<typename T>
    class Register {
    public:
        explicit Register(const std::string& identifier) {
            GetBuilders()[identifier] = []()->std::unique_ptr<ISerializer> { return std::make_unique<T>(); };
        }
    };
    static std::unique_ptr<ISerializer> Create(const std::string& identifier);
#pragma endregion
};

template<typename T>
using  SerializerRegister = ISerializer::Register<T>;

/// @brief 文档
///
/// 文档保存时指定limit是通过控制单个文件大小，来控制读取过程中内存峰值
/// 与之相对的按需加载实体策略是：
/// 1. 查找包含实体信息的文件
/// 2. 加载这些文件中的所有实体
/// 目前的序列化与反序列化都足够高效，按实体加载反而是性能浪费
class Document {
public:
    virtual ~Document() = default;

    std::vector<ISerializer*> SetSerializers(const std::vector<std::string>& identifiers);
    std::vector<ISerializer*> GetSerializers() const;

    void Open(const std::string& path);
    void Save(const std::string& path, std::size_t limit = 1024 * 1024 * 1024) const;

    template<typename T>
    T* GetRepository() const;

    /// @brief 添加存储库（Open之后调用）
    template<typename T,typename... Args>
    T* AddRepository(Args&&... args);

    template<typename T>
    T* Get(Identifier identifier) const;

    template<typename T = Entity>
    std::unordered_map<Identifier,T*> GetAll() const {
        std::unordered_map<Identifier,T*> results;
        for (auto& [id, up] : m_entities) {
            if (!up) continue;
            if constexpr (std::is_same_v<T, Entity>) {
                results[id] = up.get();
            }
            else if constexpr (std::is_base_of_v<IComponent, T>) {
                if (auto pointer = up->GetComponent<T>()) {
                    results[id] = pointer;
                }
            }
            else {
                static_assert(false);
            }
        }
        return results;
    }

    template<typename T>
    T* AddEntity()
    {
        static_assert(std::is_base_of_v<IComponent, T>);
        auto identifier = Identifier::Create();
        auto up = std::make_unique<Entity>(identifier);
        auto pointer = up->AddComponent(AccessToken{}, std::make_unique<T>());
        if constexpr (std::is_base_of_v<IEntityComponent, T>) {
            pointer->Bind(*up);
            m_entities[identifier] = std::move(up);
            if (auto it = m_repos.find(T::TypeIdentifier()); it != m_repos.end()) {
                if (it->second) {
                    it->second->Notify(*pointer);
                }
            }
        }
        else {
            m_entities[identifier] = std::move(up);
        }
        return pointer;
    }

    void Load(Identifier identifier);

    template<typename Fn>
    void Visit(const AccessToken& token, Fn fn) const {
        for (auto& [id, up] : m_entities) {
            if (up) { fn(id, *up); }
        }
    }

    inline Entity* Get(const AccessToken& token, Identifier identifier) {
        if (auto it = m_entities.find(identifier); it != m_entities.end()) {
            return it->second.get();
        }
        return nullptr;
    }

    inline void Add(const AccessToken& token, Identifier identifier, std::unique_ptr<Entity> up) {
        m_entities[identifier] = std::move(up);
    }
private:
    std::unordered_map<TypeIndex, std::unique_ptr<IRepository>> m_repos;
    std::unordered_map<Identifier, std::unique_ptr<Entity>> m_entities;

#pragma region LoadAndSave
    std::vector<std::unique_ptr<ISerializer>> m_serializers;
private:
    struct FileInfo {
        std::unordered_set<Identifier> contains;
        std::vector<ISerializer*> readers;
    };
    bool m_loading{ false };
    std::unordered_set<Entity*> m_completed;
    std::unordered_map<std::string, FileInfo> m_files;
public:
    inline void MarkCompleted(const AccessToken& token, Entity& entity) {
        assert(m_loading);
        m_completed.insert(&entity);
    }
#pragma endregion
};

/// @brief 存储库实现
/// 提供添加、查找等默认实现
template<typename Self, typename T>
class Repository :public IRepository {
    static_assert(std::is_base_of_v<IEntityComponent, T>);
public:
    template<typename U = T>
    U* Add() {
        if (!m_pDocument) return nullptr;
        return m_pDocument->AddEntity<U>();
    }
    
    T* Get(Identifier identifier) {
        if (auto it = m_entities.find(identifier); it != m_entities.end()) {
            return it->second;
        }
        return nullptr;
    }

    const std::unordered_map<Identifier,T*>& GetAll(){
        return m_entities; 
    }
public:
    const std::string& GetClassifier() const noexcept {
        static std::string classifier{ T::TypeIdentifier().GetValue() };
        return classifier;
    }

    TypeIndex GetTypeIdentifier() const noexcept override { return T::TypeIdentifier(); }

    void Bind(Document& document) override {
        m_pDocument = &document;
        m_entities = document.GetAll<T>();
    }
    void Notify(IEntityComponent& entity) override {
        if (auto pointer = entity.As<T>()) {
            m_entities[entity.GetIdentifier()] = pointer;
        }
    }
protected:
    bool IsTypeImpl(TypeId id) const noexcept override {
        return GetTypeId<Self>() == id;
    }
protected:
    std::unordered_map<Identifier, T*> m_entities;
};

template<typename T>
inline T* Document::GetRepository() const
{
    static_assert(std::is_base_of_v<IRepository, T>);
    for (auto& [identifier, pRepo] : m_repos) {
        if (!pRepo) continue;
        if (auto pResult = pRepo->As<T>()) {
            return pResult;
        }
    }
    return nullptr;
}

template<typename T, typename ...Args>
inline T* Document::AddRepository(Args && ...args)
{
    static_assert(std::is_base_of_v<IRepository, T>);
    auto up = std::make_unique<T>(std::forward<Args>(args)...);
    auto pointer = up.get();
    pointer->Bind(*this);
    TypeIndex typeIdentifier = up->GetTypeIdentifier();
    m_repos[typeIdentifier] = std::move(up);
    return pointer;
}

template<typename T>
inline T* Document::Get(Identifier identifier) const
{
    static_assert(std::is_base_of_v<IComponent, T>);
    if (auto it = m_entities.find(identifier); it != m_entities.end()) {
        if (it->second) {
            return it->second->GetComponent<T>();
        }
    }
    return nullptr;
}
