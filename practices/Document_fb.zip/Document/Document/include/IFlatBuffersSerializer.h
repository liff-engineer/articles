﻿#pragma once

#include "Document.h"
#include "flatbuffers/flatbuffer_builder.h"

class DocumentFlatBuffersFileWriter;
/// @brief  FlatBuffers序列化/反序列化实现接口
///
/// FlatBuffers使用时需要提供schema来自动生成代码，
/// 这里要求schema中使用union统一表达各种组件，即：
/// 1. 组件正常定义
/// 2. 使用union定义统一的组件数据（含union类型与组件数据void*）
/// 3. 实体包含标识符以及union数组
/// 由于union提供了类型，因而需要与组件的TypeIndex建立/存储映射关系
class IFlatBuffersSerializer :public ISerializer {
    friend class DocumentFlatBuffersFileWriter;
public:
    IFlatBuffersSerializer() = default;
protected:
    bool IsTypeImpl(TypeId id) const noexcept override {
        return GetTypeId<IFlatBuffersSerializer>() == id;
    }
private:
    void Open(Document& document, const AccessToken& token, const std::string& file, std::unordered_set<Identifier>& entities, bool complete) override;
    void Save(const Document& document, const AccessToken& token, const std::string& directory, const std::string& filename, const std::unordered_set<Identifier>& entities, std::size_t limit) override;

#pragma region Reader
protected:
    virtual void VisitFile(Document& document, const AccessToken& token ,const std::vector<char>& buffer, std::unordered_set<Identifier>& entities, bool complete) = 0;
protected:
    void VisitTypeIndex(const char* id, std::size_t index);
    Entity* VisitEntityBegin(Document& document, const AccessToken& token, const char* id);
    void VisitComponent(const AccessToken& token, Entity& entity ,std::size_t typeIndex, const void* buffer, std::size_t type,bool complete);
    void VisitEntityEnd(Document& document, Entity& entity, std::unordered_set<Identifier>& entities, bool complete);
private:
    std::vector<TypeIndex> m_typeIndexes;
#pragma endregion

#pragma region Writer
protected:
    virtual void WriteFileBegin(std::string& filename) = 0;
    virtual void WriteComponent(flatbuffers::FlatBufferBuilder& builder,TypeIndex identifier,flatbuffers::Offset<void> offset,std::size_t type) = 0;
    virtual void WriteEntity(flatbuffers::FlatBufferBuilder& builder, Identifier identifier) = 0;
    virtual void WriteFileEnd(flatbuffers::FlatBufferBuilder& builder, const std::unordered_set<TypeIndex>& typeIndexes) = 0;
#pragma endregion

#pragma region Adapater
private:
    class IAdapter {
    public:
        virtual ~IAdapter() = default;
        virtual std::unique_ptr<IComponent> Create(const AccessToken& token, const void * buffer,std::size_t type) = 0;
        virtual void Load(const AccessToken& token, const void* buffer, std::size_t type, IComponent& object) = 0;
        virtual void Save(const AccessToken& token, flatbuffers::FlatBufferBuilder& builder, flatbuffers::Offset<void>& offset,std::size_t& type,const  IComponent& object) = 0;
    };

    template<typename T>
    class Adapter final :public IAdapter {
    public:
        std::unique_ptr<IComponent> Create(const AccessToken& token, const void* buffer, std::size_t type) override
        {
            if constexpr (std::is_base_of_v<IEntityComponent, T>) {
                std::unique_ptr<T> up;
                from_flatbuffers(token, buffer, type, up);
                return up;
            }
            else {
                return std::make_unique<T>();
            }
        }

        void Load(const AccessToken& token, const void* buffer, std::size_t type, IComponent& object) override
        {
            if (T* pointer = object.As<T>()) {
                from_flatbuffers(token, buffer, type, *pointer);
            }
        }

        void Save(const AccessToken& token, flatbuffers::FlatBufferBuilder& builder, flatbuffers::Offset<void>& offset, std::size_t& type, const  IComponent& object) override {
            if (const T* pointer = object.As<T>()) {
                return to_flatbuffers(token, builder , offset, type, *pointer);
            }
        }
    };
public:
    static std::vector<std::unique_ptr<IAdapter>>& GetAdapters();
private:
    inline IAdapter* GetAdapter(TypeIndex identifier) {
        if (GetAdapters().size() > identifier.GetIndex()) {
            return GetAdapters()[identifier.GetIndex()].get();
        }
        return nullptr;
    }

public:
    template<typename T>
    class Register {
        static_assert(std::is_base_of_v<IComponent, T>);
    public:
        Register() {
            TypeIndex index = T::TypeIdentifier();
            auto& adapters = GetAdapters();
            if (adapters.size() <= index.GetIndex()) {
                adapters.resize(index.GetIndex() + 1);
            }
            adapters[index.GetIndex()] = std::make_unique<Adapter<T>>();
        }
    };
#pragma endregion
};

template<typename T>
using FlatBuffersSerializerRegister = IFlatBuffersSerializer::Register<T>;
