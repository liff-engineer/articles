﻿#include "JsonSerializer.h"

#include <filesystem>
namespace fs = std::filesystem;

void JsonSerializer::Open(Document& doc, const AccessToken& token, const std::string& file, std::unordered_set<Identifier>& entities , bool complete)
{
    fs::path path = file;
    if (!complete) {
        //尝试读取索引文件,如果没有就直接读原始文件
        fs::path path = file + ".indexes";
        if (!fs::exists(path) || !fs::is_regular_file(path)) {
            path = file;
        }
    }
    if (!fs::exists(path) || !fs::is_regular_file(path)) {
        std::cerr << "invalid file:" << path.string() << "\n";
        return;
    }

    simdjson::padded_string padded_json;
    simdjson::ondemand::document document;
    simdjson::error_code error = simdjson::padded_string::load(path.u8string()).get(padded_json);
    if (error) {
        std::cerr << error << std::endl;
        return;
    }

    document = m_parser.iterate(padded_json);
    auto json = document.at_pointer("/Entities");
    error = json.error();
    if (error) {
        std::cerr << error << std::endl;
        return;
    }

    Load(doc,token, json.value(), entities, complete);
}

bool JsonSerializer::IsAcceptedFile(const std::string& file, const std::string& ext) const
{
    return ext == ".json";
}

void JsonSerializer::Load(Document& document, const AccessToken& token, Reader& reader, std::unordered_set<Identifier>& entities, bool complete)
{
    auto object = reader.get_object();
    for (auto field : object) {
        std::string_view key;
        field.escaped_key().get(key);
        if (key.empty()) continue;
        simdjson::ondemand::value value = field.value();
        Identifier identifier = Identifier::Create(key);
        entities.insert(identifier);
        if (auto pointer = document.Get(token, identifier)) {
            Load(document,token, *pointer, value, complete);
        }
        else if (auto up = std::make_unique<Entity>(identifier))
        {
            Load(document,token, *up, value, complete);
            document.Add(token,identifier, std::move(up));
        }
    }
}

void JsonSerializer::Load(Document& document, const AccessToken& token, Entity& entity, Reader& reader, bool complete)
{
    auto object = reader.get_object();
    for (auto field : object) {
        std::string_view key;
        field.escaped_key().get(key);
        if (key.empty()) continue;
        TypeIndex identifier = TypeIndex::Create(key);
        IAdapter* pAdapter = GetAdapter(identifier);
        if (!pAdapter) continue;
        simdjson::ondemand::value value = field.value();
        if (auto pointer = entity.GetComponent(token, identifier)) {
            if (complete) {
                pAdapter->Load(token, value, *pointer);
            }
        }
        else if(auto up = pAdapter->Create(token,value))
        {
            if (complete) {
                pAdapter->Load(token, value, *up);
            }
            entity.AddComponent(token, std::move(up));
        }
    }
    if (complete) {
        document.MarkCompleted(entity);
    }
}


std::vector<std::unique_ptr<JsonSerializer::IAdapter>>& JsonSerializer::GetAdapters()
{
    static std::vector<std::unique_ptr<JsonSerializer::IAdapter>> adapters;
    return adapters;
}

class DocumentJsonFileWriter {
    fs::path m_path;
    std::string m_filename;
    fs::path m_file;
    FILE* m_pFile{};
    std::vector<char> m_buffer;
    std::unique_ptr<rapidjson::FileWriteStream> m_os;
#ifdef PRETTYWRITER
    std::unique_ptr<rapidjson::PrettyWriter<rapidjson::FileWriteStream>> m_writer;
#else
    std::unique_ptr<rapidjson::Writer<rapidjson::FileWriteStream>> m_writer;
#endif
    std::unordered_map<Identifier, Entity*> m_entities;
    int m_index{ 1 };
public:
    DocumentJsonFileWriter() = default;
    DocumentJsonFileWriter(fs::path path, std::string filename)
        :m_path(path), m_filename(std::move(filename)) {
    };

    void Begin(std::string filename)
    {
        m_entities.clear();

        m_file = m_path / (filename + ".json");
#ifdef _WIN32
        m_pFile = _wfopen(m_file.wstring().c_str(), L"wb");
#else
        m_pFile = fopen(m_file.u8string().c_str(), "wb");
#endif
        m_buffer.resize(65536);// 64KB 缓冲区
        m_os = std::make_unique<rapidjson::FileWriteStream>(m_pFile, m_buffer.data(), m_buffer.size());
#ifdef PRETTYWRITER
        m_writer = std::make_unique<rapidjson::PrettyWriter<rapidjson::FileWriteStream>>(*m_os);
#else
        m_writer = std::make_unique<rapidjson::Writer<rapidjson::FileWriteStream>>(*m_os);
#endif

        m_writer->StartObject();
        m_writer->Key("Entities");
        m_writer->StartObject();
    }

    void Save(const AccessToken& token,Entity& entity , JsonSerializer::Writer& writer, bool complete = true)
    {
        entity.Visit(token, [&](TypeIndex key,IComponent& object) {
            auto pAdapter = JsonSerializer::GetAdapter(key);
            if (!pAdapter) return;
                if (complete) {
                    std::string_view view = key.GetValue();
                    writer.Key(view.data(), view.length());
                    pAdapter->Save(token,writer, object, complete);
                }
                else if(auto pEntity = object.As<IEntityComponent>())
                {
                    std::string_view view = key.GetValue();
                    writer.Key(view.data(), view.length());
                    pAdapter->Save(token,writer, object, complete);
                }
            });
    }

    void End(const AccessToken& token)
    {
        m_writer->EndObject();
        m_writer->EndObject();
        fclose(m_pFile);

        //写入Indexes文件
#ifdef _WIN32
        fs::path index = m_file.wstring() + L".indexes";
        FILE* fp = _wfopen(index.wstring().c_str(), L"wb");
#else
        fs::path index = m_file.u8string() + ".indexes";
        FILE* fp = fopen(index.u8string().c_str(), "wb");
#endif
        std::vector<char> buffer(65536); ; // 64KB 缓冲区
        rapidjson::FileWriteStream os(fp, buffer.data(), buffer.size());
#ifdef PRETTYWRITER
        rapidjson::PrettyWriter<rapidjson::FileWriteStream> writer(os);
#else
        rapidjson::Writer<rapidjson::FileWriteStream> writer(os);
#endif
        writer.StartObject();

        writer.Key("Entities");
        writer.StartObject();

        for (auto& [identifier, pEntity] : m_entities) {
            if (!pEntity) {
                continue;
            }
            std::string_view view = identifier.GetValue();
            writer.Key(view.data(), view.length());
            writer.StartObject();
            Save(token,*pEntity,writer, false);
            writer.EndObject();
        }
        writer.EndObject();
        writer.EndObject();
        fclose(fp);
    }

    void Write(const AccessToken& token,Identifier identifier, Entity* pEntity, std::size_t limit)
    {
        if (!pEntity) return;
        std::string_view view = identifier.GetValue();
        m_writer->Key(view.data(), view.length());
        m_writer->StartObject();
        Save(token,*pEntity,*m_writer, true);
        m_writer->EndObject();

        m_entities[identifier] = pEntity;
        auto size = ftell(m_pFile);
        if (size < limit) return;

        End(token);
        Begin(m_filename + std::to_string(m_index++));
    }
};

void JsonSerializer::Save(const Document& document, const AccessToken& token, const std::string& directory, const std::string& filename, const std::unordered_set<Identifier>& identifiers, std::size_t limit)
{
    DocumentJsonFileWriter writer{ directory,filename };
    writer.Begin(filename);
    document.Visit(token, [&](Identifier identifier, Entity& entity) {
        if (auto it = identifiers.find(identifier); it != identifiers.end()) {
            writer.Write(token, identifier, &entity, limit);
        }
        });
    writer.End(token);
}

namespace
{
    SerializerRegister<JsonSerializer> JsonSerializerRegister{"Json" };
}
