﻿#include "Document.h"
#include <iostream>
#include <filesystem>
namespace fs = std::filesystem;

// Windows
#ifdef _WIN32
#include <objbase.h>
std::string generate_uuid() {
    GUID guid;
    HRESULT result = CoCreateGuid(&guid);
    char buffer[39];
    snprintf(buffer, sizeof(buffer),
        "%08lX-%04hX-%04hX-%02hhX%02hhX-%02hhX%02hhX%02hhX%02hhX%02hhX%02hhX",
        guid.Data1, guid.Data2, guid.Data3,
        guid.Data4[0], guid.Data4[1], guid.Data4[2], guid.Data4[3],
        guid.Data4[4], guid.Data4[5], guid.Data4[6], guid.Data4[7]);
    return buffer;
}
// 其他操作系统的UUID生成
#endif

void Entity::MarkCompleted(Document& document, const AccessToken& token)
{
    m_completed = true;
    for (auto& [identifier, up] : m_components) {
        if (auto pointer = up->As<IEntityComponent>()) {
            pointer->Bind(*this);
            pointer->Resolve(document);
        }
    }
}

bool IEntityComponent::IsTypeImpl(TypeId id) const noexcept
{
    return GetTypeId<IEntityComponent>() == id;
}

std::unordered_map<std::string, ISerializer::Builder>& ISerializer::GetBuilders()
{
    static std::unordered_map<std::string, ISerializer::Builder> builders;
    return builders;
}

std::unique_ptr<ISerializer> ISerializer::Create(const std::string& identifier)
{
    auto& builders = GetBuilders();
    if (auto it = builders.find(identifier); it != builders.end()) {
        return it->second();
    }
    return nullptr;
}

std::vector<ISerializer*> Document::SetSerializers(const std::vector<std::string>& identifiers)
{
    m_serializers.clear();
    m_serializers.reserve(identifiers.size());
    for (auto& identifier : identifiers) {
        if (auto up = ISerializer::Create(identifier)) {
            m_serializers.emplace_back(std::move(up));
        }
    }
    return GetSerializers();
}

std::vector<ISerializer*> Document::GetSerializers() const
{
    std::vector<ISerializer*> results;
    results.reserve(m_serializers.size());
    for (auto& up : m_serializers) {
        if (!up) continue;
        results.push_back(up.get());
    }
    return results;
}

void Document::Open(const std::string& directory)
{
    fs::path dir = directory;
    if (directory.empty()) {
        dir = fs::current_path();
    }
    if (!fs::exists(dir) || !fs::is_directory(dir)) {
        std::cerr << "invalid directory:" << dir.string() << "\n";
        return;
    }

    std::unordered_map<fs::path, std::vector<ISerializer*>> files;
    try {
        for (const auto& entry : fs::directory_iterator(dir)) {
            if (entry.is_regular_file()) {
                // 获取小写扩展名
                std::string ext = entry.path().extension().string();
                std::transform(ext.begin(), ext.end(), ext.begin(), [](unsigned char c) { return std::tolower(c); });
                fs::path file = entry.path().u8string();
                for (auto& up : m_serializers)
                {
                    if (!up) continue;
                    if (up->IsAcceptedFile(file.u8string(), ext)) {
                        files[file].push_back(up.get());
                    }
                }
            }
        }
    }
    catch (const fs::filesystem_error& e) {
        std::cerr << "filesystem error: " << e.what() << '\n';
        return;
    }
    m_files.clear();
    m_loading = true;
    for (auto& [file, readers] : files) {
        std::unordered_set<Identifier> identifiers;
        for (auto& reader : readers) {
            if (!reader) continue;
            reader->Open(*this, AccessToken{}, file.u8string(), identifiers, false);
        }
        m_files[file.u8string()] = FileInfo{ identifiers,readers };
    }

    for (auto& [id, entity] : m_entities) {
    }
    m_loading = false;
}

void Document::Save(const std::string& directory, std::size_t limit) const
{
    fs::path dir = directory;
    if (directory.empty()) {
        dir = fs::current_path();
    }
    if (!fs::exists(dir) || !fs::is_directory(dir)) {
        std::cerr << "invalid directory:" << dir.string() << "\n";
        return;
    }

    //按存储库类别分组,不在存储库中的统一放入未分类中
    std::string classifier{ "unclassify" };
    std::unordered_map<std::string, std::unordered_set<Identifier>> files;
    std::unordered_set<Identifier> visited;
    for (auto& [identifier, up] : m_repos) {
        if (!up) continue;
        std::unordered_set<Identifier>& identifiers = files[up->GetClassifier()];
        for (auto& [id, entity] : m_entities) {
            if (!entity) continue;
            if (entity->Exist(identifier)) {
                identifiers.insert(id);
                visited.insert(id);
            }
        }
    }

    std::unordered_set<Identifier>& identifiers = files[classifier];
    for (auto& [id, entity] : m_entities) {
        if (!entity) continue;
        if (visited.find(id) == visited.end()) {
            identifiers.insert(id);
        }
    }

    for (auto& [filename, identifiers] : files)
    {
        if (identifiers.empty()) continue;
        for (auto& up : m_serializers) {
            if (!up) continue;
            up->Save(*this, AccessToken{}, dir.u8string(), filename, identifiers, limit);
        }
    }
}

void Document::Load(Identifier identifier)
{
    m_loading = true;
    std::unordered_set<Identifier> entities;
    for (auto& [file, info] : m_files) {
        if (info.contains.empty()) continue;
        if (info.contains.find(identifier) == info.contains.end())
            continue;

        fs::path path = file;
        if (!fs::exists(path) || !fs::is_regular_file(path)) {
            std::cerr << "invalid file:" << path.string() << "\n";
            continue;
        }
        
        for (auto& reader: info.readers) {
            if (!reader) continue;
            reader->Open(*this, AccessToken{}, path.u8string(), entities, true);
        }
    }

    for (auto& pointer : m_completed) {
        if (!pointer) continue;
        pointer->MarkCompleted(*this, AccessToken{});
    }
    m_completed.clear();
    m_loading = false;
}

Identifier Identifier::CreateImpl(std::string_view value)
{
    static Registry object{};
    if (value.empty()) {
        return object.CreateIdentifier(generate_uuid());
    }
    return object.GetIdentifier(value);
}

TypeIndex TypeIndex::CreateImpl(std::string_view value)
{
    static Registry object{};
    return object.GetIdentifier(value);
}

