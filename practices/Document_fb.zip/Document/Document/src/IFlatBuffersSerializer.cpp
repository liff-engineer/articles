﻿#include "IFlatBuffersSerializer.h"
#include "flatbuffers/flatbuffer_builder.h"
#include <iostream>
#include <fstream>
#include <filesystem>
namespace fs = std::filesystem;

void IFlatBuffersSerializer::Open(Document& document, const AccessToken& token, const std::string& file, std::unordered_set<Identifier>& entities, bool complete)
{
    fs::path path = file;
    if (!fs::exists(path) || !fs::is_regular_file(path)) {
        std::cerr << "invalid file:" << path.string() << "\n";
        return;
    }

    std::ifstream ifs(path, std::ifstream::binary);
    if (!ifs) {
        std::cerr << "cannot open file:" << path.string() << "\n";
        return;
    }

    // 获取文件大小
    ifs.seekg(0, ifs.end);
    size_t length = ifs.tellg();
    ifs.seekg(0, ifs.beg);

    // 读取到缓冲区
    std::vector<char> buffer(length);
    ifs.read(buffer.data(), length);
    ifs.close();

    m_typeIndexes.clear();
    VisitFile(document, token, buffer, entities, complete);
}

void IFlatBuffersSerializer::VisitTypeIndex(const char* identifier, std::size_t index)
{
    if (m_typeIndexes.size() <= index) {
        m_typeIndexes.resize(index + 1);
    }
    m_typeIndexes[index] = TypeIndex::Create(identifier);
}

Entity* IFlatBuffersSerializer::VisitEntityBegin(Document& document, const AccessToken& token, const char* id)
{
    Identifier identifier = Identifier::Create(id);
    Entity* pEntity = document.Get(token, identifier);
    if (!pEntity) {
        if (auto up = std::make_unique<Entity>(identifier))
        {
            pEntity = up.get();
            document.Add(token, identifier, std::move(up));
        }
    }
    return pEntity;
}

void IFlatBuffersSerializer::VisitComponent(const AccessToken& token, Entity& entity, std::size_t typeIndex, const void* buffer, std::size_t type, bool complete)
{
    TypeIndex identifier = m_typeIndexes[typeIndex];
    if (!identifier) return;
    auto pAdapter = GetAdapter(identifier);
    if (!pAdapter) return;
    if (auto pointer = entity.GetComponent(token, identifier)) {
        if (complete) {
            pAdapter->Load(token, buffer, type, *pointer);
        }
    }
    else if (auto up = pAdapter->Create(token, buffer, type))
    {
        if (complete) {
            pAdapter->Load(token, buffer, type, *up);
        }
        entity.AddComponent(token, std::move(up));
    }
}

void IFlatBuffersSerializer::VisitEntityEnd(Document& document, Entity& entity, std::unordered_set<Identifier>& entities, bool complete)
{
    entities.insert(entity.GetIdentifier());
    if (complete) {
        document.MarkCompleted(entity);
    }
}

class DocumentFlatBuffersFileWriter {
    IFlatBuffersSerializer& m_serializer;
    fs::path m_path;
    std::string m_filename;
    fs::path m_file;
    int m_index{ 1 };
    flatbuffers::FlatBufferBuilder m_builder{};
    std::unordered_set<TypeIndex> m_types;
public:
    DocumentFlatBuffersFileWriter(IFlatBuffersSerializer& serializer,fs::path path, std::string filename)
        :m_serializer(serializer), m_path(path), m_filename(std::move(filename)) {
    };

    inline IFlatBuffersSerializer::IAdapter* GetAdapter(TypeIndex identifier) {
        auto& adapters = IFlatBuffersSerializer::GetAdapters();
        if (adapters.size() > identifier.GetIndex()) {
            return adapters[identifier.GetIndex()].get();
        }
        return nullptr;
    }

    void Begin(std::string filename)
    {
        m_types.clear();
        m_serializer.WriteFileBegin(filename);
        m_file = m_path /filename;
    }

    void Save(const AccessToken& token,TypeIndex identifier, IComponent& object)
    {
        auto pAdapter = GetAdapter(identifier);
        if (!pAdapter) return;
        m_types.insert(identifier);
        flatbuffers::Offset<void> offset{};
        std::size_t type{};
        pAdapter->Save(token, m_builder, offset, type, object);
        if (offset.IsNull()) return;

        m_serializer.WriteComponent(m_builder, identifier, offset, type);
    }

    void End(const AccessToken& token)
    {
        m_serializer.WriteFileEnd(m_builder, m_types);

        std::ofstream ofs(m_file, std::ofstream::binary);
        auto buffer = m_builder.GetBufferPointer();
        auto size = m_builder.GetSize();
        ofs.write(reinterpret_cast<const char*>(buffer),size);
        ofs.close();
        m_builder.Clear();

        std::cout << "Serialized data saved to " << m_file << std::endl;
    }

    void Write(const AccessToken& token, Identifier identifier, Entity& entity, std::size_t limit)
    {
        entity.Visit(token, [&](TypeIndex index, IComponent& object) { Save(token, index, object); });
        m_serializer.WriteEntity(m_builder, identifier);

        auto size = m_builder.GetSize();
        if (size < limit) return;

        End(token);
        Begin(m_filename + std::to_string(m_index++));
    }
};

void IFlatBuffersSerializer::Save(const Document& document, const AccessToken& token, const std::string& directory, const std::string& filename, const std::unordered_set<Identifier>& identifiers, std::size_t limit)
{
    DocumentFlatBuffersFileWriter writer{*this, directory,filename };
    writer.Begin(filename);
    document.Visit(token, [&](Identifier identifier, Entity& entity) {
        if (auto it = identifiers.find(identifier); it != identifiers.end()) {
            writer.Write(token, identifier, entity, limit);
        }
        });
    writer.End(token);
}

std::vector<std::unique_ptr<IFlatBuffersSerializer::IAdapter>>& IFlatBuffersSerializer::GetAdapters()
{
    static std::vector<std::unique_ptr<IFlatBuffersSerializer::IAdapter>> adapters;
    return adapters;
}
